/* Shared chrome, atmosphere, sound and components for The Green Fields Beyond */
(function () {
  /* ---------- Two languages ----------
     Every page exists twice: name.html (English) and name.ru.html (Russian), with the same pictures and sounds.
     The page says which language it is in on <body data-lang="ru">; the shared chrome follows it. */
  const LANG = () => document.body && document.body.dataset.lang === "ru" ? "ru" : "en";
  const T = (en, ru) => LANG() === "ru" ? ru : en;
  const ALL_PAGES = ["index", "the-call", "trenches", "before-the-storm", "over-the-top", "tanks", "the-cost", "remembrance", "map", "faces", "myths", "examination", "enlist", "service-record", "sources"];
  // the English file name of the page at this path; hosts may serve pages without ".html" (Cloudflare Pages does), and the entrance at the bare address
  const baseName = path => { const b = String(path).split("/").pop().replace(/\.html$/, "").replace(/\.ru$/, ""); return ALL_PAGES.includes(b) ? b + ".html" : "index.html"; };
  const inLang = (href, lang) => { // the same page in the given language
    const m = String(href).match(/^([^#?]*?)(\.ru)?\.html([#?].*)?$/); if (!m) return href;
    return m[1] + (lang === "ru" ? ".ru.html" : ".html") + (m[3] || "");
  };
  const P = href => inLang(href, LANG());
  window.SiteLang = { get: LANG, T, P, inLang };
  try { document.documentElement.lang = LANG(); } catch (e) {}
  const ACTS = [
    { id: "promise", label: ["Promise", "Обещание"], tab: ["Promise", "Обещание"], href: "the-call.html", dot: "#b3261e" },
    { id: "mud", label: ["Mud", "Грязь"], tab: ["Mud", "Грязь"], href: "trenches.html", dot: "#8a6a45" },
    { id: "blood", label: ["Blood", "Кровь"], tab: ["Blood", "Кровь"], href: "over-the-top.html", dot: "#9e2a20" },
    { id: "green", label: ["Green Fields", "Зелёные поля"], tab: ["Fields", "Поля"], href: "the-cost.html", dot: "#7f9a64" }
  ];
  const ARCHIVE = [
    { href: "map.html", label: ["Map & Timeline", "Карта и хронология"] },
    { href: "myths.html", label: ["Myth vs. Reality", "Мифы и факты"] },
    { href: "examination.html", label: ["The Examination (quiz)", "Экзамен (тест)"] },
    { href: "sources.html", label: ["Sources", "Источники"] },
    { href: "service-record.html", label: ["Your service record", "Ваше личное дело"] }
  ];
  const L = pair => LANG() === "ru" ? pair[1] : pair[0];

  /* ---------- Every page opens at the top ----------
     Browsers (and the page viewer) can restore the old scroll position after following a link,
     which left visitors at the bottom of the next page. Always start at the beginning instead. */
  try { history.scrollRestoration = "manual"; } catch (e) {}
  const toTop = () => {
    if (location.hash && location.hash.length > 1) return;
    const r = document.documentElement, prev = r.style.scrollBehavior;
    r.style.scrollBehavior = "auto"; window.scrollTo(0, 0);
    requestAnimationFrame(() => { window.scrollTo(0, 0); r.style.scrollBehavior = prev; });
  };
  toTop();
  addEventListener("DOMContentLoaded", toTop);
  addEventListener("load", toTop);
  addEventListener("pageshow", toTop);

  // Each page's listeners and timers hang off this; it is aborted when the visitor moves to another page.
  let pageCtl = new AbortController(), pageTimers = [];
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };

  /* ---------- Atmosphere ---------- */
  const body = document.body;
  const curAct = () => body.dataset.act || "";
  const grain = document.createElement("div"); grain.className = "grain"; grain.setAttribute("aria-hidden", "true");
  const fog = document.createElement("div"); fog.className = "fog"; fog.setAttribute("aria-hidden", "true");
  fog.innerHTML = "<i></i><i></i><i></i>"; grain.dataset.keep = ""; fog.dataset.keep = "";
  body.prepend(fog); body.append(grain);
  // Smooth, lumpy edge used by the Mud act's panels
  const defs = document.createElement("div");
  defs.setAttribute("aria-hidden", "true"); defs.dataset.keep = "";
  defs.style.cssText = "position:absolute;width:0;height:0;overflow:hidden";
  defs.innerHTML = '<svg width="0" height="0"><filter id="mud-edge" x="-8%" y="-8%" width="116%" height="116%"><feTurbulence type="fractalNoise" baseFrequency="0.011" numOctaves="2" seed="7" result="t"/><feDisplacementMap in="SourceGraphic" in2="t" scale="26" xChannelSelector="R" yChannelSelector="G"/></filter></svg>';
  body.append(defs);

  /* ---------- Header ---------- */
  {
    const head = document.createElement("header");
    head.className = "site-head"; head.dataset.keep = "";
    head.innerHTML = `
      <div class="wrap">
        <a class="brand" href="${P("index.html")}">${T("The Green Fields Beyond", "Зелёные поля вдали")}<small>${T("Somme 1916", "Сомма, 1916")}</small></a>
        <nav class="acts-nav" aria-label="${T("The four acts", "Четыре акта")}"><ol class="acts">
          ${ACTS.map(a => `<li><a href="${P(a.href)}" style="--dot:${a.dot}" data-act-link="${a.id}">${L(a.label)}</a></li>`).join("")}
        </ol></nav>
        <div class="head-tools">
          <div class="archive-menu">
            <button class="btn" id="archive-btn" aria-expanded="false" aria-controls="archive-list">${T("Archive", "Архив")} &#9662;</button>
            <ul id="archive-list" hidden>
              ${ARCHIVE.map(a => `<li><a href="${P(a.href)}">${L(a.label)}</a></li>`).join("")}
            </ul>
          </div>
          <a class="btn acct-link" id="acct-link" href="${P("enlist.html")}" title="${T("Register or log in", "Регистрация или вход")}">${T("Enlist", "Записаться")}</a>
          <a class="btn lang-link" id="lang-link" href="#" data-lang-link lang="${T("ru", "en")}" hreflang="${T("ru", "en")}" title="${T("Русская версия сайта", "English version of the site")}">${T("RU", "EN")}</a>
          <button class="btn" id="sound-btn" aria-pressed="false" title="${T("Sound effects and music. Off by default.", "Звуковые эффекты и музыка. По умолчанию выключены.")}">${T("Sound: off", "Звук: выкл.")}</button>
        </div>
      </div>`;
    body.prepend(head);
    const ab = head.querySelector("#archive-btn"), al = head.querySelector("#archive-list");
    ab.addEventListener("click", () => { const open = al.hidden; al.hidden = !open; ab.setAttribute("aria-expanded", String(open)); });
    document.addEventListener("click", e => { if (!head.querySelector(".archive-menu").contains(e.target)) { al.hidden = true; ab.setAttribute("aria-expanded", "false"); } });
    document.addEventListener("keydown", e => { if (e.key === "Escape") { al.hidden = true; ab.setAttribute("aria-expanded", "false"); } });

    /* Phones and tablets held upright: the acts live in a tab bar along the bottom, in thumb reach.
       No hidden "burger" menu: every act is always one tap away, and Archive opens a panel above the bar. */
    const tabs = document.createElement("nav");
    tabs.className = "tabbar"; tabs.dataset.keep = ""; tabs.setAttribute("aria-label", T("Acts and archive", "Акты и архив"));
    tabs.innerHTML = ACTS.map(a => `<a href="${P(a.href)}" style="--dot:${a.dot}" data-act-link="${a.id}"><i aria-hidden="true"></i><span>${L(a.tab)}</span></a>`).join("")
      + `<button type="button" id="tab-archive" style="--dot:#c9a25e" data-act-link="archive" aria-expanded="false" aria-controls="tab-sheet"><i aria-hidden="true"></i><span>${T("Archive", "Архив")}</span></button>`;
    const sheet = document.createElement("div");
    sheet.className = "tab-sheet"; sheet.id = "tab-sheet"; sheet.dataset.keep = ""; sheet.hidden = true;
    sheet.innerHTML = `<p class="eyebrow">${T("The Archive", "Архив")}</p><ul>${ARCHIVE.filter(a => a.href !== "service-record.html").map(a => `<li><a href="${P(a.href)}">${L(a.label)}</a></li>`).join("")}
      <li><a href="${P("enlist.html")}" data-acct-link data-acct-long="${T("Enlist or log in", "Записаться или войти")}">${T("Enlist or log in", "Записаться или войти")}</a></li>
      <li class="sheet-lang"><a href="#" data-lang-link lang="${T("ru", "en")}" hreflang="${T("ru", "en")}">${T("Русская версия", "English version")}</a></li></ul>`;
    body.append(sheet, tabs);
    const tb = tabs.querySelector("#tab-archive");
    const setSheet = open => { sheet.hidden = !open; tb.setAttribute("aria-expanded", String(open)); body.classList.toggle("sheet-open", open); };
    tb.addEventListener("click", e => { e.stopPropagation(); setSheet(sheet.hidden); });
    document.addEventListener("click", e => { if (!sheet.hidden && !sheet.contains(e.target)) setSheet(false); });
    document.addEventListener("keydown", e => { if (e.key === "Escape") setSheet(false); });
    sheet.addEventListener("click", e => { if (e.target.closest("a")) setSheet(false); });

    const foot = document.createElement("footer");
    foot.className = "site-foot"; foot.dataset.keep = "";
    foot.innerHTML = T(`<div class="wrap"><span>The Green Fields Beyond &middot; a student history project on the Battle of the Somme, 1 July &ndash; 18 November 1916</span><span>Every quote and figure is listed on the <a href="sources.html">Sources</a> page &middot; Every sound and recording is credited on the Sources page</span></div>`,
      `<div class="wrap"><span>Зелёные поля вдали &middot; ученический исторический проект о битве на Сомме, 1 июля &ndash; 18 ноября 1916 года</span><span>Все цитаты и цифры перечислены на странице <a href="sources.ru.html">«Источники»</a> &middot; там же указаны авторы всех звуков и записей</span></div>`);
    body.append(foot);
  }

  /* ---------- Sound (Web Audio, synthesised) ----------
     No recordings: everything is built from filtered noise, run through a synthetic
     reverb so it sounds like it is happening outdoors across a valley. */
  let ctx = null, dry = null, wet = null, master = null, ambientTimer = null, mgTimer = null, bedGain = null;
  const Sound = {
    enabled: false,
    init() {
      if (ctx) return;
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      ctx = new AC();
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -20; comp.knee.value = 12; comp.ratio.value = 5; comp.attack.value = .003; comp.release.value = .4;
      master = ctx.createGain(); master.gain.value = 1;
      master.connect(comp); comp.connect(ctx.destination);
      // Outdoor reverb: long decaying stereo noise impulse
      const len = Math.floor(ctx.sampleRate * 3), ir = ctx.createBuffer(2, len, ctx.sampleRate);
      for (let ch = 0; ch < 2; ch++) {
        const d = ir.getChannelData(ch);
        for (let i = 0; i < len; i++) { const x = i / len; d[i] = (Math.random() * 2 - 1) * Math.pow(1 - x, 3.2) * (i < ctx.sampleRate * .03 ? i / (ctx.sampleRate * .03) : 1); }
      }
      const conv = ctx.createConvolver(); conv.buffer = ir;
      const wetLP = ctx.createBiquadFilter(); wetLP.type = "lowpass"; wetLP.frequency.value = 2200;
      wet = ctx.createGain(); wet.gain.value = .35; wet.connect(conv); conv.connect(wetLP); wetLP.connect(master);
      dry = ctx.createGain(); dry.gain.value = 1; dry.connect(master);
      // Shared noise buffers
      const n = Math.floor(ctx.sampleRate * 6);
      this.white = ctx.createBuffer(1, n, ctx.sampleRate);
      this.brown = ctx.createBuffer(1, n, ctx.sampleRate);
      const w = this.white.getChannelData(0), b = this.brown.getChannelData(0); let last = 0;
      for (let i = 0; i < n; i++) { const r = Math.random() * 2 - 1; w[i] = r; last = (last + .02 * r) / 1.02; b[i] = last * 3.5; }
      // Low rumble bed (silent until a page asks for it)
      const bed = ctx.createBufferSource(); bed.buffer = this.brown; bed.loop = true;
      const bedLP = ctx.createBiquadFilter(); bedLP.type = "lowpass"; bedLP.frequency.value = 180;
      bedGain = ctx.createGain(); bedGain.gain.value = 0;
      // slow swell in the rumble: a separate stage so it is silent when the level is 0
      const swell = ctx.createGain(); swell.gain.value = .7;
      const lfo = ctx.createOscillator(), lfoG = ctx.createGain(); lfo.frequency.value = .13; lfoG.gain.value = .3;
      lfo.connect(lfoG); lfoG.connect(swell.gain);
      bed.connect(bedLP); bedLP.connect(swell); swell.connect(bedGain); bedGain.connect(dry); bedGain.connect(wet);
      bed.start(); lfo.start();
    },
    src(buf, off) { const s = ctx.createBufferSource(); s.buffer = buf; s._off = off ?? Math.random() * .5; return s; },
    out(node, wetAmt) { node.connect(dry); const g = ctx.createGain(); g.gain.value = wetAmt; node.connect(g); g.connect(wet); },
    // dist 1 = close, 6 = far away
    shell(dist = 1, when = 0) {
      if (!this.enabled || !ctx) return;
      const t = ctx.currentTime + when, v = Math.min(1, 1.4 / dist), far = Math.min(1, (dist - 1) / 5);
      // the blast: a wide noise burst whose brightness falls away
      const a = this.src(this.white), af = ctx.createBiquadFilter(), ag = ctx.createGain();
      af.type = "lowpass"; af.Q.value = .5;
      af.frequency.setValueAtTime(5000 * (1 - far * .85), t); af.frequency.exponentialRampToValueAtTime(220, t + .9);
      ag.gain.setValueAtTime(0, t); ag.gain.linearRampToValueAtTime(.9 * v, t + .006 + far * .05);
      ag.gain.exponentialRampToValueAtTime(.001, t + 1.6 + far);
      a.connect(af); af.connect(ag); this.out(ag, .4 + far * .9);
      a.start(t, a._off); a.stop(t + 3);
      // the roll: deep rumble that swells and lingers
      const r = this.src(this.brown), rf = ctx.createBiquadFilter(), rg = ctx.createGain();
      rf.type = "lowpass"; rf.frequency.value = 260 - far * 120;
      rg.gain.setValueAtTime(0, t); rg.gain.linearRampToValueAtTime(1.3 * v, t + .08 + far * .2);
      rg.gain.exponentialRampToValueAtTime(.001, t + 3.5 + far * 2);
      r.connect(rf); rf.connect(rg); this.out(rg, .7);
      r.start(t, r._off); r.stop(t + 6);
      // debris: earth and stones pattering down (close shells only)
      if (dist < 3) for (let i = 0; i < 18; i++) {
        const dt = .25 + Math.random() * 1.6, c = this.src(this.white), cf = ctx.createBiquadFilter(), cg = ctx.createGain();
        cf.type = "bandpass"; cf.frequency.value = 1500 + Math.random() * 2500; cf.Q.value = 1.5;
        cg.gain.setValueAtTime(.12 * v * Math.random(), t + dt); cg.gain.exponentialRampToValueAtTime(.001, t + dt + .03);
        c.connect(cf); cf.connect(cg); this.out(cg, .3); c.start(t + dt, c._off); c.stop(t + dt + .04);
      }
    },
    // A trench whistle (pea whistle): shrill tone, rattling trill from the pea, breathy edge.
    // blasts: [[start, length], ...] in seconds; dist 1 = right next to you.
    whistle(dist = 1, when = 0, f = 3150, blasts = [[0, 1.4]]) {
      if (!this.enabled || !ctx) return;
      const t0 = ctx.currentTime + .03 + when, v = Math.min(1, 1.15 / dist), far = Math.min(1, (dist - 1) / 4);
      const out = ctx.createGain(); out.gain.value = .32 * v;
      const tone = ctx.createBiquadFilter(); tone.type = "highpass"; tone.frequency.value = 900;
      const dull = ctx.createBiquadFilter(); dull.type = "lowpass"; dull.frequency.value = 11000 - far * 7000;
      tone.connect(dull); dull.connect(out); this.out(out, .25 + far * .9);
      blasts.forEach(([s0, len]) => {
        const a = t0 + s0, e = a + len;
        // pitch: overshoots as the blast starts, settles, sags slightly as breath runs out
        const o1 = ctx.createOscillator(), o2 = ctx.createOscillator(), o3 = ctx.createOscillator();
        o1.type = "sine"; o2.type = "triangle"; o3.type = "sine";
        [[o1, 1], [o2, 1.004], [o3, 2]].forEach(([o, m]) => {
          o.frequency.setValueAtTime(f * m * 1.06, a); o.frequency.exponentialRampToValueAtTime(f * m, a + .06);
          o.frequency.setValueAtTime(f * m, e - .15); o.frequency.exponentialRampToValueAtTime(f * m * .96, e);
        });
        // the pea: fast, slightly irregular rattle in both pitch and loudness
        const trill = ctx.createOscillator(), trill2 = ctx.createOscillator(), tg = ctx.createGain(), fg = ctx.createGain();
        trill.type = "square"; trill.frequency.value = 27 + Math.random() * 10; trill2.type = "sine"; trill2.frequency.value = 7 + Math.random() * 4;
        const t2g = ctx.createGain(); t2g.gain.value = 6; trill2.connect(t2g); t2g.connect(trill.frequency);
        tg.gain.value = .45; fg.gain.value = f * .035;
        trill.connect(tg); trill.connect(fg); [o1, o2, o3].forEach(o => fg.connect(o.frequency));
        const amp = ctx.createGain(); amp.gain.value = .55; tg.connect(amp.gain);
        const g1 = ctx.createGain(), g2 = ctx.createGain(), g3 = ctx.createGain(); g1.gain.value = 1; g2.gain.value = .35; g3.gain.value = .18;
        o1.connect(g1); o2.connect(g2); o3.connect(g3); [g1, g2, g3].forEach(g => g.connect(amp));
        // breath
        const br = this.src(this.white), bf = ctx.createBiquadFilter(), bg = ctx.createGain();
        bf.type = "bandpass"; bf.frequency.value = f; bf.Q.value = 3; bg.gain.value = .5; br.connect(bf); bf.connect(bg); bg.connect(amp);
        // envelope: hard attack, sustain, quick cut
        const env = ctx.createGain(); amp.connect(env); env.connect(tone);
        env.gain.setValueAtTime(0, a); env.gain.linearRampToValueAtTime(1, a + .015); env.gain.setValueAtTime(1, e - .05); env.gain.linearRampToValueAtTime(0, e);
        [o1, o2, o3, trill, trill2].forEach(x => { x.start(a); x.stop(e + .05); }); br.start(a, br._off); br.stop(e + .05);
      });
    },
    // One-shot recorded samples (e.g. the trench whistle), cached once decoded
    async loadSample(url) {
      if (!ctx) return null;
      if (this.recBuf[url]) return this.recBuf[url];
      try { const ab = await (await fetch(url)).arrayBuffer(); return (this.recBuf[url] = await ctx.decodeAudioData(ab)); } catch (e) { return null; }
    },
    playSample(buf, when = 0, rate = 1, gain = 1, bright = 16000, wetAmt = .2) {
      if (!this.enabled || !ctx || !buf) return;
      const t = ctx.currentTime + .02 + when, s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
      s.buffer = buf; s.playbackRate.value = rate; f.type = "lowpass"; f.frequency.value = bright; g.gain.value = gain;
      s.connect(f); f.connect(g); this.out(g, wetAmt); s.start(t);
    },
    // Zero hour: the recorded trench whistle, once. Falls back to the synthesised whistles if it can't load.
    async whistleChorus() {
      if (!this.enabled || !ctx) return;
      const buf = await this.loadSample("audio/whistle.mp3");
      if (!buf) return this.whistleChorusSynth();
      this.playSample(buf, 0, 1, 1, 16000, .18); // just the one whistle: your officer's
    },
    whistleChorusSynth() {
      if (!this.enabled || !ctx) return;
      this.whistle(1, 0, 3150, [[0, .22], [.3, .22], [.6, 1.9]]);
      const others = 7;
      for (let i = 0; i < others; i++) {
        const when = .35 + Math.random() * 2.6, dist = 1.6 + Math.random() * 3.6, f = 2700 + Math.random() * 900;
        const pattern = Math.random() < .5 ? [[0, .9 + Math.random() * 1.1]] : [[0, .2], [.28, .2], [.56, .8 + Math.random() * .8]];
        this.whistle(dist, when, f, pattern);
      }
      this.whistle(1.3, 3.1, 3350, [[0, .25], [.33, 1.2]]);
    },
    // Machine-gun bursts. Uses a real recording of a Maxim-type gun (the family of the German MG 08)
    // cut into bursts of varying length; falls back to the synthesised version until it has loaded.
    mgActive: [],
    // Cut off any machine-gun bursts still playing or queued (used when the visitor moves on)
    stopMG(secs = .15) {
      if (!ctx) { this.mgActive = []; return; }
      const t = ctx.currentTime;
      this.mgActive.forEach(({ s, g }) => { try { g.gain.cancelScheduledValues(t); g.gain.setValueAtTime(g.gain.value, t); g.gain.linearRampToValueAtTime(0, t + secs); s.stop(t + secs + .02); } catch (e) {} });
      this.mgActive = [];
    },
    mg(bursts = 3, dist = 1, when = 0) {
      if (!this.enabled || !ctx) return;
      const buf = this.recBuf["audio/mg-maxim.mp3"];
      if (!buf) { this.loadSample("audio/mg-maxim.mp3"); return this.mgSynth(bursts, dist, when); }
      let t = ctx.currentTime + .03 + when;
      const v = Math.min(1, 1.3 / dist), far = Math.min(1, (dist - 1) / 5);
      for (let b = 0; b < bursts; b++) {
        const len = .5 + Math.random() * 1.6, off = Math.random() * Math.max(0, buf.duration - len - .05);
        const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
        s.buffer = buf; s.playbackRate.value = .94 + Math.random() * .08;
        f.type = "lowpass"; f.frequency.value = 12000 - far * 9500;
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + .015); g.gain.setValueAtTime(v, t + len - .05); g.gain.linearRampToValueAtTime(0, t + len);
        s.connect(f); f.connect(g); this.out(g, .3 + far * .9); s.start(t, off, len + .05);
        this.mgActive.push({ s, g }); s.onended = () => { this.mgActive = this.mgActive.filter(x => x.s !== s); };
        t += len + .5 + Math.random() * 1.1;
      }
    },
    mgSynth(bursts = 3, dist = 1, when = 0) {
      if (!this.enabled || !ctx) return;
      // Vickers-style: about 8 rounds a second, each a sharp crack with a short body
      let t = ctx.currentTime + .05 + when;
      const v = Math.min(1, 1.2 / dist), far = Math.min(1, (dist - 1) / 5);
      for (let b = 0; b < bursts; b++) {
        const shots = 6 + Math.floor(Math.random() * 12);
        for (let i = 0; i < shots; i++) {
          const n = this.src(this.white), f = ctx.createBiquadFilter(), g = ctx.createGain();
          f.type = "lowpass"; f.frequency.value = 6000 - far * 4500;
          g.gain.setValueAtTime(.9 * v, t); g.gain.exponentialRampToValueAtTime(.001, t + .045);
          n.connect(f); f.connect(g); this.out(g, .5 + far * .8); n.start(t, n._off); n.stop(t + .06); this.mgActive.push({ s: n, g });
          const p = this.src(this.brown), pf = ctx.createBiquadFilter(), pg = ctx.createGain();
          pf.type = "lowpass"; pf.frequency.value = 400; pg.gain.setValueAtTime(.8 * v, t); pg.gain.exponentialRampToValueAtTime(.001, t + .09);
          p.connect(pf); pf.connect(pg); this.out(pg, .4); p.start(t, p._off); p.stop(t + .1);
          t += .118 + Math.random() * .02;
        }
        t += .5 + Math.random() * .9;
      }
    },
    bed(level, secs = 2) { if (!ctx) return; const t = ctx.currentTime; bedGain.gain.cancelScheduledValues(t); bedGain.gain.setValueAtTime(bedGain.gain.value, t); bedGain.gain.linearRampToValueAtTime(level, t + secs); },
    // mode: "distant" (far-off guns), "front" (closer, with machine guns), "drumfire" (the final bombardment), or off
    ambient(mode, _rate, near) {
      clearTimeout(ambientTimer); clearTimeout(mgTimer); ambientTimer = mgTimer = null;
      if (mode === true) mode = near ? "front" : "distant";
      if (!mode || !this.enabled) { this.bed(0, 1.5); return; }
      const cfg = {
        distant: { bed: .25, gap: [2500, 7000], dist: [4, 6] },
        front: { bed: .45, gap: [1200, 3500], dist: [2, 5], mg: true },
        drumfire: { bed: 1, gap: [120, 450], dist: [2.5, 6] }
      }[mode];
      this.bed(cfg.bed);
      const rnd = ([a, b]) => a + Math.random() * (b - a);
      const loop = () => { this.shell(rnd(cfg.dist)); ambientTimer = setTimeout(loop, rnd(cfg.gap)); };
      ambientTimer = setTimeout(loop, 300);
      if (cfg.mg) { const ml = () => { this.mg(1 + Math.floor(Math.random() * 2), 3 + Math.random() * 2); mgTimer = setTimeout(ml, 5000 + Math.random() * 8000); }; mgTimer = setTimeout(ml, 2500); }
    },
    silence() {
      this.ambient(false); this.stopRecording(.4); this.stopTipperary(.4);
      if (master && ctx) { const t = ctx.currentTime; this.bed(0, .3); master.gain.cancelScheduledValues(t); master.gain.setValueAtTime(master.gain.value, t); master.gain.linearRampToValueAtTime(0, t + .5); master.gain.setValueAtTime(1, t + 4); }
    },
    // A real recorded barrage, looped (used on the Mud pages)
    rec: null, recBuf: {},
    async playRecording(url, level = .55, bright = 3200, fallback = null) {
      if (!this.enabled || !ctx || this.rec) return;
      const token = this.rec = { url };
      try {
        if (!this.recBuf[url]) {
          const res = await fetch(url);
          const ab = await res.arrayBuffer();
          this.recBuf[url] = await ctx.decodeAudioData(ab);
        }
        if (this.rec !== token || !this.enabled) return;
        const buf = this.recBuf[url], src = ctx.createBufferSource(), lp = ctx.createBiquadFilter(), g = ctx.createGain();
        src.buffer = buf; src.loop = true; src.loopStart = .05; src.loopEnd = buf.duration - .05;
        lp.type = "lowpass"; lp.frequency.value = bright;
        const t = ctx.currentTime; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(level, t + 3);
        src.connect(lp); lp.connect(g); g.connect(master); src.start(t, .05);
        token.src = src; token.g = g;
      } catch (e) {
        this.rec = null; if (fallback) fallback(); else this.ambient("distant"); // fall back to the synthesised sound
      }
    },
    // "It's a Long Way to Tipperary" (Judge & Williams, 1912; public domain), chorus.
    // Melody and chords from the Nottingham Music Database transcription (abcnotation.com).
    // Played as a brisk military brass band with drums, as at the railway station in 1914, looping.
    tune: null,
    playTipperary(level = .62) {
      if (!this.enabled || !ctx || this.tune) return;
      const N = n => 440 * Math.pow(2, (({ C: -9, D: -7, E: -5, F: -4, G: -2, A: 0, B: 2 })[n[0]] + (n.includes("#") ? 1 : 0) + 12 * (parseInt(n.slice(-1)) - 4)) / 12);
      // [note, beats]; ties already merged
      const MEL = [["F#4",1],["G4",1],
        ["A4",2],["A4",3],["A4",1],["B4",1],["C#5",1],["D5",2],["F#5",4],["F#5",1],["E5",1],["D5",2],["B4",4],["D5",2],["A4",5],["G4",1],["F#4",1],["G4",1],
        ["A4",2],["A4",3],["A4",1],["B4",1],["C#5",1],["D5",2],["F#5",4],["C#5",1],["D5",1],["E5",2],["B4",2],["C#5",2],["D5",2],["E5",6],["F#4",1],["G4",1],
        ["A4",2],["A4",3],["A4",1],["B4",1],["C#5",1],["D5",2],["F#5",5],["F#5",1],["G5",2],["B4",2],["D5",2],["E5",2],["F#5",6],["D5",1],["E5",1],
        ["F#5",2],["F#5",2],["F#5",1],["D5",1],["E5",1],["D5",1],["B4",4],["A4",2],["D5",1],["E5",1],["F#5",2],["D5",4],["E5",2],["D5",6]];
      const CH = { D: ["D2","A2",["D3","F#3","A3"]], D7: ["D2","A2",["D3","F#3","C4"]], G: ["G2","D3",["G3","B3","D4"]],
        A7: ["A2","E2",["G3","C#4","E4"]], E7: ["E2","B2",["E3","G#3","D4"]], "F#7": ["F#2","C#3",["F#3","A#3","E4"]] };
      const BARS = "D D D D7 G G D A7 D D D D E7 E7 A7 A7 D D D D G G F#7 A7 D D G D E7 A7 D D".split(" ");
      const bpm = 124, beat = 60 / bpm, LOOP = 128; // brisk march; 2 pickup beats + 31 bars + final half bar
      // a brass band heard on an old record: bright, with only a faint crackle
      const bus = ctx.createGain(); bus.gain.value = 0;
      const hp = ctx.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 110;
      const lp = ctx.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 7000;
      bus.connect(hp); hp.connect(lp); lp.connect(master);
      const rv = ctx.createGain(); rv.gain.value = .22; lp.connect(rv); rv.connect(wet);
      const t0 = ctx.currentTime + .15;
      bus.gain.setValueAtTime(0, t0); bus.gain.linearRampToValueAtTime(level, t0 + .4);
      const hiss = this.src(this.white); hiss.loop = true; const hf = ctx.createBiquadFilter(), hg = ctx.createGain();
      hf.type = "bandpass"; hf.frequency.value = 3000; hf.Q.value = .6; hg.gain.value = .012; hiss.connect(hf); hf.connect(hg); hg.connect(bus); hiss.start(t0);
      // brass: buzzy sawtooth that brightens as it's blown, with a little vibrato on held notes
      const brass = (freq, t, dur, vol, cut) => {
        const o = ctx.createOscillator(), o2 = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain();
        o.type = "sawtooth"; o2.type = "square"; o.frequency.value = freq; o2.frequency.value = freq * 1.004;
        if (dur > beat * 1.5) { const v = ctx.createOscillator(), vg = ctx.createGain(); v.frequency.value = 5.5; vg.gain.setValueAtTime(0, t); vg.gain.linearRampToValueAtTime(freq * .006, t + .35); v.connect(vg); vg.connect(o.frequency); vg.connect(o2.frequency); v.start(t); v.stop(t + dur + .1); }
        const m2 = ctx.createGain(); m2.gain.value = .35; o2.connect(m2); m2.connect(f); o.connect(f);
        f.type = "lowpass"; f.Q.value = 2; f.frequency.setValueAtTime(cut * .35, t); f.frequency.linearRampToValueAtTime(cut, t + .04); f.frequency.linearRampToValueAtTime(cut * .7, t + Math.min(dur, .4));
        const rel = Math.max(.06, dur - .04);
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + .025); g.gain.linearRampToValueAtTime(vol * .78, t + .12); g.gain.setValueAtTime(vol * .78, t + rel); g.gain.linearRampToValueAtTime(0, t + rel + .05);
        f.connect(g); g.connect(bus); o.start(t); o2.start(t); o.stop(t + dur + .15); o2.stop(t + dur + .15);
      };
      // piccolo doubling the tune an octave up, for sparkle
      const fife = (freq, t, dur, vol) => {
        const o = ctx.createOscillator(), g = ctx.createGain(); o.type = "triangle"; o.frequency.value = freq * 2;
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + .02); g.gain.setValueAtTime(vol, t + Math.max(.05, dur - .05)); g.gain.linearRampToValueAtTime(0, t + dur);
        o.connect(g); g.connect(bus); o.start(t); o.stop(t + dur + .05);
      };
      const drum = (t, kind, vol) => {
        if (kind === "bass") {
          const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(110, t); o.frequency.exponentialRampToValueAtTime(48, t + .15);
          g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + .3); o.connect(g); g.connect(bus); o.start(t); o.stop(t + .32);
        } else {
          const n = this.src(this.white), f = ctx.createBiquadFilter(), g = ctx.createGain();
          f.type = kind === "cymbal" ? "highpass" : "bandpass"; f.frequency.value = kind === "cymbal" ? 5000 : 2200; f.Q.value = .7;
          const len = kind === "cymbal" ? 1.4 : .13;
          g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + len);
          n.connect(f); f.connect(g); g.connect(bus); n.start(t, n._off); n.stop(t + len + .02);
        }
      };
      // build one pass as timed events
      const events = []; let b = 0;
      MEL.forEach(([n, d]) => {
        const dur = d * beat * (d > 1 ? .92 : .8); // short notes detached and bouncy
        events.push({ at: b, fn: t => { brass(N(n), t, dur, .2, 3400); fife(N(n), t, dur, .035); } });
        b += d;
      });
      const pah = (x, t) => x.forEach(y => brass(N(y) * 2, t, beat * .38, .045, 2200));
      BARS.forEach((c, i) => {
        const [root, fifth, chord] = CH[c], bar = 2 + i * 4;
        [[0, root, "b"], [1, chord, "c"], [2, fifth, "b"], [3, chord, "c"]].forEach(([k, x, kind]) => {
          if (bar + k >= LOOP) return;
          events.push({ at: bar + k, fn: t => {
            if (kind === "b") { brass(N(x), t, beat * .55, .19, 700); drum(t, "bass", k === 0 ? .55 : .35); }
            else { pah(x, t); drum(t, "snare", .16); }
          } });
          // snare flam on the off-beat "and" of 4 now and then, for swagger
          if (k === 3 && i % 4 === 3 && bar + k + .5 < LOOP) events.push({ at: bar + k + .5, fn: t => drum(t, "snare", .12) });
        });
        if (i % 8 === 0) events.push({ at: bar, fn: t => drum(t, "cymbal", i === 0 ? .2 : .1) });
      });
      // pickup: a snare roll leading into the first bar, and the crash that starts each pass
      events.push({ at: 0, fn: t => { for (let r = 0; r < 8; r++) drum(t + r * beat / 4, "snare", .05 + r * .012); } });
      events.sort((a, b) => a.at - b.at);
      const state = this.tune = { bus, hiss, next: t0, pass: 0, idx: 0 };
      const tick = () => {
        if (this.tune !== state) return;
        const horizon = ctx.currentTime + .6;
        while (true) {
          const ev = events[state.idx], t = state.next + ev.at * beat;
          if (t > horizon) break;
          ev.fn(t);
          state.idx++;
          if (state.idx >= events.length) { state.idx = 0; state.next += LOOP * beat; } // straight round again, like a band on the march
        }
      };
      tick(); state.timer = setInterval(tick, 200);
    },
    stopTipperary(secs = 1.5) {
      const s = this.tune; this.tune = null;
      if (!s || !ctx) return;
      clearInterval(s.timer);
      const t = ctx.currentTime; s.bus.gain.cancelScheduledValues(t); s.bus.gain.setValueAtTime(s.bus.gain.value, t); s.bus.gain.linearRampToValueAtTime(0, t + secs);
      s.hiss.stop(t + secs + .1);
    },
    stopRecording(secs = 1.5) {
      const r = this.rec; this.rec = null;
      if (!r || !r.src || !ctx) return;
      const t = ctx.currentTime; r.g.gain.cancelScheduledValues(t); r.g.gain.setValueAtTime(r.g.gain.value, t); r.g.gain.linearRampToValueAtTime(0, t + secs);
      r.src.stop(t + secs + .1);
    },
    // Play an act's recording; if it is already playing (another page of the same act), just carry on.
    track(url, level, bright, fallback) {
      if (this.rec && this.rec.url === url) return;
      this.stopRecording(1.8); this.stopTipperary(1.8);
      this.playRecording(url, level, bright, fallback);
    },
    pageAmbient() {
      const mode = body.dataset.ambient || ({ promise: "tipperary", mud: "barrage", blood: "barrage-close", green: "fields" })[curAct()] || "none";
      if (mode === "tipperary") { this.ambient(false); this.track("audio/tipperary-band.mp3", .6, 16000, () => this.playTipperary()); } // recorded band; synthesised march if it fails to load
      else if (mode === "fields") { this.ambient(false); this.track("audio/green-fields.mp3", .55, 16000); } // the Green Fields: the song chosen by the author
      else if (mode === "barrage") { this.ambient(false); this.track("audio/mud-ambience.mp3", .5, 7000); } // the Mud: its own battlefield ambience
      else if (mode === "barrage-close") { this.ambient(false); this.track("audio/barrage-loop.mp3", .85, 9000); this.loadSample("audio/mg-maxim.mp3"); } // the Blood: closer, louder, brighter
      else if (mode === "none") { this.ambient(false); this.stopRecording(1.8); this.stopTipperary(1.8); } // the Archive pages (map, myths, examination, sources) are quiet
      else this.ambient(mode);
    }
  };
  window.Sound = Sound;
  Sound.state = () => ctx ? ctx.state : "none";
  Sound.on = () => { if (!Sound.enabled) setSound(true); };
  const sb = document.getElementById("sound-btn");
  function setSound(on) {
    Sound.enabled = on;
    if (on) { Sound.init(); if (ctx && ctx.state !== "running") ctx.resume(); }
    if (sb) { sb.setAttribute("aria-pressed", String(on)); sb.textContent = on ? T("Sound: on", "Звук: вкл.") : T("Sound: off", "Звук: выкл."); }
    if (on) { Sound.pageAmbient(); } else { Sound.ambient(false); Sound.stopRecording(.5); Sound.stopTipperary(.5); }
    store.set("somme-sound", on ? "1" : "0");
    document.dispatchEvent(new CustomEvent("soundchange", { detail: on }));
  }
  if (sb) sb.addEventListener("click", () => setSound(!Sound.enabled));
  // Remember the choice across pages. Browsers only allow audio after an interaction,
  // so it resumes on the first click or key press (but not a click on the sound button itself).
  if (store.get("somme-sound") === "1" && sb) {
    sb.textContent = T("Sound: tap to resume", "Звук: нажмите, чтобы включить");
    const arm = e => {
      if (sb.contains(e.target)) return;
      setSound(true);
      document.removeEventListener("pointerdown", arm); document.removeEventListener("keydown", arm);
    };
    document.addEventListener("pointerdown", arm); document.addEventListener("keydown", arm);
  }

  /* ---------- Accounts: Enlist (registration) and the Service Record (personal cabinet) ----------
     Where the visitor's Claude account allows it, the record is kept online in this site's private
     per-person storage (it follows them to any device). Otherwise it is kept in this browser.
     Passwords are never stored: only a salted PBKDF2 hash. */
  const PAGES = ["the-call.html", "trenches.html", "before-the-storm.html", "faces.html", "over-the-top.html", "tanks.html", "the-cost.html", "remembrance.html"];
  const readJSON = (k, d) => { try { return JSON.parse(store.get(k)) || d; } catch (e) { return d; } };
  const Progress = {
    get() { const p = readJSON("somme-progress", {}); p.visited = p.visited || {}; p.fate = store.get("somme-pals-fate") || p.fate || null; const r = readJSON("somme-pals-roster", null); if (r) p.roster = r; return p; },
    save(p) { store.set("somme-progress", JSON.stringify(p)); Account.pushProgress(p); },
    visit(page) { if (!PAGES.includes(page)) return; const p = this.get(); if (p.visited[page]) return; p.visited[page] = new Date().toISOString().slice(0, 10); this.save(p); },
    exam(right, of, result) { const p = this.get(); const best = p.exam; if (!best || right >= best.right) p.exam = { right, of, result, on: new Date().toISOString().slice(0, 10) }; this.save(p); clearTimeout(Account._push); return Account.pushNow ? Account.pushNow(p) : null; },
    candle() { const p = this.get(); if (!p.candle) { p.candle = new Date().toISOString().slice(0, 10); this.save(p); } },
    vote(v) { const p = this.get(); p.vote = v; this.save(p); },
    merge(a, b) { // combine two progress records: union of pages, best exam, earliest candle, latest vote
      a = a || {}; b = b || {}; const m = { visited: { ...(b.visited || {}), ...(a.visited || {}) } };
      m.exam = [a.exam, b.exam].filter(Boolean).sort((x, y) => y.right - x.right)[0] || null;
      m.candle = [a.candle, b.candle].filter(Boolean).sort()[0] || null;
      m.vote = a.vote || b.vote || null; m.fate = a.fate || b.fate || null; m.roster = a.roster || b.roster || null; return m;
    }
  };
  window.Progress = Progress;

  const enc = new TextEncoder();
  const hex = buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
  async function hashPw(pw, saltHex) {
    const salt = saltHex ? new Uint8Array(saltHex.match(/../g).map(h => parseInt(h, 16))) : crypto.getRandomValues(new Uint8Array(16));
    const key = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: 120000, hash: "SHA-256" }, key, 256);
    return { salt: hex(salt), hash: hex(bits) };
  }
  const clean = t => String(t || "").replace(/\s+/g, " ").trim();
  const cleanEmail = t => String(t || "").trim().toLowerCase();
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const checkEmail = e => { if (!EMAIL_RE.test(e) || e.length > 120) throw err("email", T("Please give a valid email address, like name@example.com.", "Укажите действительный адрес электронной почты, например name@example.com.")); };
  const err = (code, message) => Object.assign(new Error(message), { code });
  const checkBorn = v => { // a real date, not in the future, at most 110 years ago
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v || ""), d = m && new Date(+m[1], +m[2] - 1, +m[3]), now = new Date();
    if (!d || d.getMonth() !== +m[2] - 1 || d > now || now.getFullYear() - d.getFullYear() > 110) throw err("born", T("Please choose your date of birth on the calendar.", "Выберите дату рождения в календаре."));
    return v;
  };

  /* The site's own database: Supabase. The publishable key is designed to be public; every table is protected
     by row-level security, so each recruit can only read and change their own file. */
  const SUPABASE_URL = "https://fduxddlwteolqrkzhzbk.supabase.co";
  const SUPABASE_KEY = "sb_publishable_pFl2WSJ0AHEMjNmFqq_9Fg_sZsktzv4";
  let sbPromise = null;
  function supabaseClient() {
    if (sbPromise) return sbPromise;
    return sbPromise = (async () => {
      try {
        if (!window.supabase || !window.supabase.createClient) await new Promise((res, rej) => {
          const s = document.createElement("script"); s.src = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js";
          s.onload = res; s.onerror = rej; document.head.append(s); setTimeout(() => rej(new Error("timeout")), 8000);
        });
        // is the server reachable from here? (some hosts block outside connections)
        const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 6000);
        const r = await fetch(SUPABASE_URL + "/auth/v1/health", { headers: { apikey: SUPABASE_KEY }, signal: ctl.signal }); clearTimeout(t);
        if (!r.ok) return null;
        return window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY, { auth: { persistSession: true, autoRefreshToken: true, storageKey: "somme-supabase-auth" } });
      } catch (e) { return null; }
    })();
  }
  // Supabase's own error messages, put into plain words
  const sbErr = e => {
    const m = String(e && e.message || e || "");
    if (/already registered|already been registered|User already/i.test(m)) return err("exists", T("An account with that email address already exists. Report for duty (log in) instead.", "Учётная запись с этим адресом уже существует. Вместо этого явитесь на службу (войдите)."));
    if (/Invalid login credentials/i.test(m)) return err("login", T("That email and password do not match our records.", "Такого сочетания адреса и пароля в наших записях нет."));
    if (/Email not confirmed/i.test(m)) return err("confirm", T("Please confirm your email address first: open the link in the email we sent you, then log in.", "Сначала подтвердите адрес электронной почты: откройте ссылку в письме, которое мы вам отправили, а затем войдите."));
    if (/rate limit|too many/i.test(m)) return err("rate", T("Too many attempts. Please wait a minute and try again.", "Слишком много попыток. Подождите минуту и попробуйте снова."));
    if (/Password should|weak/i.test(m)) return err("password", T("That password is too weak. Use at least 8 characters, mixing letters and numbers.", "Этот пароль слишком простой. Используйте не меньше 8 символов, сочетая буквы и цифры."));
    if (/not authorized|sending confirmation|Error sending/i.test(m)) return err("mail", T("We could not send the confirmation email to that address. Please ask the author of this site to check the email settings.", "Не удалось отправить письмо с подтверждением на этот адрес. Попросите автора сайта проверить настройки почты."));
    if (/address .* is invalid|invalid.*email|Unable to validate email/i.test(m)) return err("email", T("That email address was not accepted. Please check it and try again.", "Этот адрес электронной почты не принят. Проверьте его и попробуйте снова."));
    if (/Failed to fetch|NetworkError|network/i.test(m)) return err("network", T("Could not reach the site's database. Please check your connection and try again.", "Не удалось связаться с базой данных сайта. Проверьте подключение к интернету и попробуйте снова."));
    return err("server", T("The database said: ", "Ответ базы данных: ") + m);
  };
  const sbRow = async (sb, user) => { // this recruit's row, created from their sign-up details if it is missing
    const { data, error } = await sb.from("profiles").select("*").eq("id", user.id).maybeSingle();
    if (error) throw sbErr(error);
    if (data) return data;
    const meta = user.user_metadata || {};
    const row = { id: user.id, name: meta.name || user.email.split("@")[0], hometown: meta.hometown || null, born: meta.born || null, progress: Progress.get() };
    const ins = await sb.from("profiles").insert(row).select().single();
    if (ins.error) throw sbErr(ins.error);
    return ins.data;
  };
  const sbRec = (row, user) => ({ name: row.name, email: user.email, hometown: row.hometown || "", born: row.born || "", enlisted: row.enlisted, progress: row.progress || {}, mode: "supabase" });

  // The highest rank won in the Examination becomes part of the recruit's name
  const rankOf = rec => { const e = rec && rec.progress && rec.progress.exam; return e && e.of && e.right / e.of >= .5
    ? { key: "2lt", short: T("2nd Lt", "Младший лейтенант"), long: T("Second Lieutenant", "Младший лейтенант") }
    : { key: "pte", short: T("Pte", "Рядовой"), long: T("Private", "Рядовой") }; };
  const styled = rec => rankOf(rec).short + " " + rec.name;
  // A Second Lieutenant's badge of rank: one "pip", the eight-pointed Star of the Order of the Bath
  const PIP = () => `<svg class="pip" viewBox="0 0 24 24" width="18" height="18" role="img" aria-label="${T("Second Lieutenant\u2019s pip", "Звёздочка младшего лейтенанта")}"><polygon points="12,2 13.6,8.1 19.1,4.9 15.9,10.4 22,12 15.9,13.6 19.1,19.1 13.6,15.9 12,22 10.4,15.9 4.9,19.1 8.1,13.6 2,12 8.1,10.4 4.9,4.9 10.4,8.1"/><circle cx="12" cy="12" r="3.6"/><circle cx="12" cy="12" r="1.6"/></svg>`;
  const pipFor = rec => rankOf(rec).key === "2lt" ? PIP() : "";

  const Account = {
    rankOf, styled, pipFor,
    _backend: null,
    // Decide once where records live: online (Claude account storage) or this browser.
    backend() {
      if (this._backend) return this._backend;
      return this._backend = (async () => {
        const sb = await supabaseClient(); if (sb) return { mode: "supabase", sb };
        try {
          if (!window.claude || !claude.use) return { mode: "local" };
          const [db, user] = await Promise.all([claude.use("db"), claude.use("user")]);
          if (!db || !user) return { mode: "local" };
          const uid = await user.id(); if (!uid) return { mode: "local" };
          const can = user.can ? await user.can("data.write") : null;
          if (can === false) return { mode: "local" };
          return { mode: "online", db, uid, ref: db.doc("data/users/" + uid + "/profile") };
        } catch (e) { return { mode: "local" }; }
      })();
    },
    localAll() { return readJSON("somme-accounts", {}); },
    localSave(all) { store.set("somme-accounts", JSON.stringify(all)); },
    async load() { // the stored record for this visitor's session, or null
      const b = await this.backend();
      if (b.mode === "supabase") {
        try { const { data } = await b.sb.auth.getSession(); const u = data && data.session && data.session.user; if (!u) return null; return sbRec(await sbRow(b.sb, u), u); }
        catch (e) { return null; }
      }
      if (b.mode === "online") {
        if (store.get("somme-session") !== "online:" + b.uid) return null;
        try { const snap = await b.ref.get(); return snap.exists ? { ...snap.data(), mode: "online" } : null; } catch (e) { return null; }
      }
      const name = store.get("somme-session"); if (!name || name.startsWith("online:")) return null;
      const rec = this.localAll()[name.toLowerCase()]; return rec ? { ...rec, mode: "local" } : null;
    },
    async write(rec) {
      const b = await this.backend(), body = { ...rec }; delete body.mode;
      if (b.mode === "supabase") {
        const { data } = await b.sb.auth.getSession(); const u = data && data.session && data.session.user; if (!u) throw err("session", T("Please log in again.", "Пожалуйста, войдите снова."));
        const { error } = await b.sb.from("profiles").update({ name: body.name, hometown: body.hometown || null, born: body.born || null, progress: body.progress || {}, updated_at: new Date().toISOString() }).eq("id", u.id);
        if (error) throw sbErr(error); return;
      }
      if (b.mode === "online") {
        try { await b.ref.set(body); return; }
        catch (e) { if (e && e.code === "invalid_argument") { this._backend = Promise.resolve({ mode: "local" }); throw err("readonly", T("Your Claude account can only read this site, so your record will be kept in this browser instead. Please try again.", "Ваша учётная запись Claude может только читать этот сайт, поэтому ваше дело будет храниться в этом браузере. Попробуйте ещё раз.")); } throw err("network", T("Could not reach the online records. Please try again in a moment.", "Не удалось связаться с онлайн-хранилищем. Попробуйте ещё раз через минуту.")); }
      }
      const all = this.localAll(); all[body.name.toLowerCase()] = body; this.localSave(all);
    },
    async register({ name, email, hometown, born, password }) {
      name = clean(name); hometown = clean(hometown); email = cleanEmail(email); born = checkBorn(born);
      if (name.length < 2 || name.length > 40) throw err("name", T("Please give a name between 2 and 40 characters.", "Имя должно содержать от 2 до 40 символов."));
      if (!/^[\p{L}\p{N} .'\-]+$/u.test(name)) throw err("name", T("Names may use letters, numbers, spaces, full stops, apostrophes and hyphens.", "В имени можно использовать буквы, цифры, пробелы, точки, апострофы и дефисы."));
      checkEmail(email);
      if (String(password || "").length < 8) throw err("password", T("The password must be at least 8 characters long.", "Пароль должен содержать не меньше 8 символов."));
      const b = await this.backend();
      if (b.mode === "supabase") {
        const { data, error } = await b.sb.auth.signUp({ email, password, options: { data: { name, hometown: hometown.slice(0, 60), born }, emailRedirectTo: location.origin + location.pathname.replace(/[^/]*$/, "") + P("enlist.html") } });
        if (error) throw sbErr(error);
        // with "Confirm email" switched on, Supabase returns no session (and hides whether the address was already taken)
        if (!data.session) return { pending: true, email, mode: "supabase" };
        const row = await sbRow(b.sb, data.user); this.changed(); return sbRec(row, data.user);
      }
      if (b.mode !== "online" && Object.values(this.localAll()).some(r => r.email === email)) throw err("email", T("That email address is already used by a recruit in this browser. Log in instead.", "Этот адрес уже использует другой новобранец в этом браузере. Вместо регистрации войдите."));
      if (b.mode === "online") { const snap = await b.ref.get().catch(() => null); if (snap && snap.exists) throw err("exists", T("This Claude account already has a service record. Report for duty (log in) instead.", "У этой учётной записи Claude уже есть личное дело. Вместо этого явитесь на службу (войдите).")); }
      else if (this.localAll()[name.toLowerCase()]) throw err("exists", T("A recruit by that name has already enlisted in this browser. Choose another name, or log in.", "Новобранец с таким именем уже записался в этом браузере. Выберите другое имя или войдите."));
      const pw = await hashPw(password);
      const rec = { name, email, hometown: hometown.slice(0, 60), born, enlisted: new Date().toISOString().slice(0, 10), salt: pw.salt, hash: pw.hash, progress: Progress.get() };
      await this.write(rec);
      store.set("somme-session", b.mode === "online" ? "online:" + b.uid : name);
      this.changed(); return { ...rec, mode: b.mode };
    },
    async login({ name, password }) { // "name" may be the recruit's name or their email address
      const id = clean(name).toLowerCase();
      const matches = r => r && (r.name.toLowerCase() === id || (r.email || "") === id);
      const b = await this.backend(); let rec = null;
      if (b.mode === "supabase") {
        if (!id.includes("@")) throw err("login", T("Please log in with your email address.", "Для входа укажите адрес электронной почты."));
        const { data, error } = await b.sb.auth.signInWithPassword({ email: id, password });
        if (error) throw sbErr(error);
        const row = await sbRow(b.sb, data.user);
        const merged = Progress.merge(Progress.get(), row.progress);
        store.set("somme-progress", JSON.stringify(merged));
        await b.sb.from("profiles").update({ progress: merged, updated_at: new Date().toISOString() }).eq("id", data.user.id);
        this.changed(); return sbRec({ ...row, progress: merged }, data.user);
      }
      if (b.mode === "online") { const snap = await b.ref.get().catch(() => null); rec = snap && snap.exists ? snap.data() : null; if (!matches(rec)) rec = null; }
      else rec = Object.values(this.localAll()).find(matches) || null;
      const bad = err("login", T("That name or email and password do not match our records.", "Такого сочетания имени (или адреса) и пароля в наших записях нет."));
      if (!rec) throw bad;
      const pw = await hashPw(password, rec.salt); if (pw.hash !== rec.hash) throw bad;
      store.set("somme-session", b.mode === "online" ? "online:" + b.uid : rec.name);
      const merged = { ...rec, progress: Progress.merge(Progress.get(), rec.progress) };
      store.set("somme-progress", JSON.stringify(merged.progress)); await this.write(merged);
      this.changed(); return { ...merged, mode: b.mode };
    },
    async update(fields) {
      const rec = await this.load(); if (!rec) throw err("session", T("Please log in again.", "Пожалуйста, войдите снова."));
      const email = cleanEmail(fields.email); checkEmail(email);
      if (rec.mode === "supabase") {
        const b = await this.backend(); let note = "";
        if (email !== rec.email) { const { error } = await b.sb.auth.updateUser({ email }); if (error) throw sbErr(error); note = T("We have sent a link to " + email + ". The new address takes effect once you open it.", "Мы отправили ссылку на " + email + ". Новый адрес начнёт действовать, когда вы её откроете."); }
        const next = { ...rec, hometown: clean(fields.hometown).slice(0, 60), born: fields.born === undefined ? rec.born : checkBorn(fields.born) }; await this.write(next); this.changed(); return { ...next, note };
      }
      if (rec.mode !== "online" && Object.values(this.localAll()).some(r => r.email === email && r.name !== rec.name)) throw err("email", T("That email address is already used by another recruit in this browser.", "Этот адрес уже использует другой новобранец в этом браузере."));
      const next = { ...rec, email, hometown: clean(fields.hometown).slice(0, 60), born: fields.born === undefined ? rec.born : checkBorn(fields.born) }; await this.write(next); this.changed(); return next;
    },
    async changePassword(oldPw, newPw) {
      const rec = await this.load(); if (!rec) throw err("session", T("Please log in again.", "Пожалуйста, войдите снова."));
      if (rec.mode === "supabase") {
        if (String(newPw || "").length < 8) throw err("password", T("The new password must be at least 8 characters long.", "Новый пароль должен содержать не меньше 8 символов."));
        const b = await this.backend();
        const chk = await b.sb.auth.signInWithPassword({ email: rec.email, password: oldPw }); if (chk.error) throw err("password", T("Your current password is not right.", "Текущий пароль указан неверно."));
        const { error } = await b.sb.auth.updateUser({ password: newPw }); if (error) throw sbErr(error); return;
      }
      if ((await hashPw(oldPw, rec.salt)).hash !== rec.hash) throw err("password", T("Your current password is not right.", "Текущий пароль указан неверно."));
      if (String(newPw || "").length < 8) throw err("password", T("The new password must be at least 8 characters long.", "Новый пароль должен содержать не меньше 8 символов."));
      const pw = await hashPw(newPw); await this.write({ ...rec, salt: pw.salt, hash: pw.hash });
    },
    async logout() {
      const b = await this.backend();
      if (b.mode === "supabase") { try { await b.sb.auth.signOut(); } catch (e) {} }
      store.set("somme-session", ""); this.changed();
    },
    // Delete the signed-in recruit's file: the account itself and everything recorded about them.
    async remove() {
      const b = await this.backend(), rec = await this.load();
      if (rec && b.mode === "supabase") {
        const { error } = await b.sb.rpc("delete_my_account"); if (error) throw sbErr(error);
        try { await b.sb.auth.signOut(); } catch (e) {}
        this.forgetHere(); return;
      }
      if (rec) { if (b.mode === "online") await b.ref.delete(); else { const all = this.localAll(); delete all[rec.name.toLowerCase()]; this.localSave(all); } }
      this.forgetHere();
    },
    // For someone who cannot log in: delete every record this site keeps for them, without a password.
    // Online that is only their own Claude account's file; in a browser it is everything saved in this browser.
    async wipe() {
      const b = await this.backend();
      if (b.mode === "supabase") { try { await b.sb.auth.signOut(); } catch (e) {} }
      if (b.mode === "online") { try { await b.ref.delete(); } catch (e) {} }
      store.set("somme-accounts", "{}");
      this.forgetHere();
    },
    forgetHere() { // reading progress, the Pals fate and the login, as stored in this browser
      ["somme-progress", "somme-pals-fate", "somme-pals-roster", "somme-session"].forEach(k => { try { localStorage.removeItem(k); } catch (e) {} });
      this.changed();
    },
    _push: null,
    async pushNow(p) { const rec = await this.load(); if (!rec) return null; const next = { ...rec, progress: Progress.merge(p, rec.progress) }; try { await this.write(next); } catch (e) {} this.changed(); return next; },
    pushProgress(p) { // keep the signed-in record's progress in step, at most one write every few seconds
      clearTimeout(this._push);
      this._push = setTimeout(async () => { const rec = await this.load(); if (rec) { try { await this.write({ ...rec, progress: Progress.merge(p, rec.progress) }); } catch (e) {} } }, 2500);
    },
    async changed() { // refresh every Enlist / My record link (header, entrance page)
      const links = document.querySelectorAll("#acct-link, [data-acct-link]"); if (!links.length) return;
      const rec = await this.load();
      links.forEach(a => {
        a.textContent = rec ? (a.dataset.acctLong ? T("Your service record", "Ваше личное дело") : T("My record", "Моё дело")) : (a.dataset.acctLong || T("Enlist", "Записаться"));
        a.href = P(rec ? "service-record.html" : "enlist.html");
        a.title = rec ? T("Service record of ", "Личное дело: ") + styled(rec) : T("Register or log in", "Регистрация или вход");
      });
    }
  };
  window.Account = Account;

  /* ---------- Date of birth: a printed desk calendar of the period ----------
     BirthCal.mount(host, { value: "YYYY-MM-DD", onChange }) fills host with the calendar and returns { get, set }.
     Month and year are ordinary drop-down lists; the days are buttons, moved between with the arrow keys. */
  const MONTHS = [["January", "Январь", "января"], ["February", "Февраль", "февраля"], ["March", "Март", "марта"], ["April", "Апрель", "апреля"],
    ["May", "Май", "мая"], ["June", "Июнь", "июня"], ["July", "Июль", "июля"], ["August", "Август", "августа"], ["September", "Сентябрь", "сентября"],
    ["October", "Октябрь", "октября"], ["November", "Ноябрь", "ноября"], ["December", "Декабрь", "декабря"]];
  const iso = (y, m, d) => y + "-" + String(m + 1).padStart(2, "0") + "-" + String(d).padStart(2, "0");
  const today = () => { const t = new Date(); return { y: t.getFullYear(), m: t.getMonth(), d: t.getDate() }; };
  const parseDay = v => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v || ""); return m ? { y: +m[1], m: +m[2] - 1, d: +m[3] } : null; };
  const ageOf = born => { const b = parseDay(born); if (!b) return null; const t = today(); return t.y - b.y - (t.m < b.m || (t.m === b.m && t.d < b.d) ? 1 : 0); };
  const ageText = n => LANG() === "ru" ? years(n) : n + (n === 1 ? " year" : " years") + " old";
  const longDay = v => { const b = parseDay(v); if (!b) return ""; return LANG() === "ru" ? b.d + "\u00a0" + MONTHS[b.m][2] + " " + b.y + "\u00a0г." : b.d + "\u00a0" + MONTHS[b.m][0] + " " + b.y; };
  // what the recruiting office of 1914 would have made of a recruit this age
  const ageNote = n => n < 18
    ? T("In 1914 you would have been too young: recruits had to be 18, and 19 to be sent overseas. Many boys lied about their age anyway: an estimated 250,000 under-18s served in the British Army during the war.",
        "В 1914 году вас бы не взяли: добровольцу должно было быть не меньше 18 лет, а для отправки за границу — 19. Но многие мальчишки прибавляли себе возраст: по оценкам, за годы войны в британской армии служило около 250\u00a0000 юношей младше 18 лет.")
    : n === 18 ? T("In 1914 you would have been old enough to enlist, but not to be sent overseas until you turned 19.",
        "В 1914 году вас бы уже приняли в армию, но отправить за границу могли только после того, как вам исполнится 19.")
    : n <= 30 ? T("In August 1914 you would have been exactly who Kitchener’s first appeal was asking for: men aged 19 to 30.",
        "В августе 1914 года первый призыв Китченера обращался бы именно к вам: он звал мужчин от 19 до 30 лет.")
    : T("Kitchener’s first appeal in August 1914 asked for men aged 19 to 30, but within weeks the upper limit was raised, and older men joined too.",
        "Первый призыв Китченера в августе 1914 года обращался к мужчинам от 19 до 30 лет, но уже через несколько недель верхнюю границу подняли, и в армию пошли и мужчины постарше.");
  const BirthCal = {
    ageOf, ageText, ageNote, longDay, parse: parseDay,
    mount(host, opts = {}) {
      const t = today(), first = t.y - 110, uid = "bc" + Math.random().toString(36).slice(2, 7);
      let sel = parseDay(opts.value), view = sel ? { y: sel.y, m: sel.m } : { y: t.y - 16, m: 0 }, focusDay = sel ? sel.d : 1;
      const heads = LANG() === "ru" ? ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"] : ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
      host.classList.add("bcal");
      host.innerHTML = `
        <div class="bcal-top" aria-hidden="true"><span></span><b>${T("Almanack", "Календарь")}</b><span></span></div>
        <div class="bcal-head">
          <button type="button" class="bcal-step" data-step="-1" aria-label="${T("Previous month", "Предыдущий месяц")}">&lsaquo;</button>
          <div class="bcal-pick">
            <select class="bcal-m" aria-label="${T("Month of birth", "Месяц рождения")}">${MONTHS.map((m, i) => `<option value="${i}">${L(m)}</option>`).join("")}</select>
            <select class="bcal-y" aria-label="${T("Year of birth", "Год рождения")}">${Array.from({ length: t.y - first + 1 }, (_, i) => t.y - i).map(y => `<option>${y}</option>`).join("")}</select>
          </div>
          <button type="button" class="bcal-step" data-step="1" aria-label="${T("Next month", "Следующий месяц")}">&rsaquo;</button>
        </div>
        <div class="bcal-grid" role="group" aria-label="${T("Day of birth", "День рождения")}" id="${uid}"></div>
        <p class="bcal-out" aria-live="polite"></p>`;
      const $m = host.querySelector(".bcal-m"), $y = host.querySelector(".bcal-y"), grid = host.querySelector(".bcal-grid"), out = host.querySelector(".bcal-out");
      const later = (y, m, d) => y > t.y || (y === t.y && (m > t.m || (m === t.m && d > t.d)));
      function draw(keepFocus) {
        $m.value = view.m; $y.value = view.y;
        const days = new Date(view.y, view.m + 1, 0).getDate(), lead = (new Date(view.y, view.m, 1).getDay() + 6) % 7;
        focusDay = Math.min(focusDay, days);
        let h = heads.map((d, i) => `<span class="bcal-wd${i === 6 ? " sun" : ""}" aria-hidden="true">${d}</span>`).join("");
        h += "<span></span>".repeat(lead);
        for (let d = 1; d <= days; d++) {
          const on = sel && sel.y === view.y && sel.m === view.m && sel.d === d, off = later(view.y, view.m, d), sun = (lead + d - 1) % 7 === 6;
          h += `<button type="button" class="bcal-d${sun ? " sun" : ""}${on ? " on" : ""}" data-d="${d}" tabindex="${d === focusDay ? 0 : -1}" aria-pressed="${on}"${off ? " disabled" : ""} aria-label="${longDay(iso(view.y, view.m, d))}">${d}</button>`;
        }
        grid.innerHTML = h;
        host.querySelector('[data-step="1"]').disabled = view.y === t.y && view.m === t.m;
        host.querySelector('[data-step="-1"]').disabled = view.y === first && view.m === 0;
        if (keepFocus) { const b = grid.querySelector(`[data-d="${focusDay}"]`); if (b && !b.disabled) b.focus(); }
        const v = sel && iso(sel.y, sel.m, sel.d), n = v && ageOf(v);
        out.innerHTML = v ? `<b>${T("Born", "Дата рождения:")} ${longDay(v)}</b> &middot; ${ageText(n)}<span class="bcal-note">${ageNote(n)}</span>` : T("Choose the month and year, then the day.", "Выберите месяц и год, а затем день.");
      }
      const move = (dm) => { let m = view.m + dm, y = view.y; if (m < 0) { m = 11; y--; } if (m > 11) { m = 0; y++; } if (y < first || later(y, m, 1)) return false; view = { y, m }; return true; };
      host.querySelectorAll(".bcal-step").forEach(b => b.addEventListener("click", () => { if (move(+b.dataset.step)) draw(); }));
      $m.addEventListener("change", () => { view.m = +$m.value; if (later(view.y, view.m, 1)) view.m = t.m; draw(); });
      $y.addEventListener("change", () => { view.y = +$y.value; if (later(view.y, view.m, 1)) view.m = t.m; draw(); });
      grid.addEventListener("click", e => { const b = e.target.closest(".bcal-d"); if (!b || b.disabled) return; focusDay = +b.dataset.d; sel = { ...view, d: focusDay }; draw(true); opts.onChange && opts.onChange(api.get()); });
      grid.addEventListener("keydown", e => {
        const k = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 }[e.key]; if (!k) return; e.preventDefault();
        let d = focusDay + k; const days = new Date(view.y, view.m + 1, 0).getDate();
        if (d < 1) { if (!move(-1)) return; d += new Date(view.y, view.m + 1, 0).getDate(); }
        else if (d > days) { if (!move(1)) return; d -= days; }
        if (later(view.y, view.m, d)) return;
        focusDay = d; draw(true);
      });
      const api = { get: () => sel ? iso(sel.y, sel.m, sel.d) : "", set: v => { sel = parseDay(v); if (sel) { view = { y: sel.y, m: sel.m }; focusDay = sel.d; } draw(); }, focus: () => $m.focus() };
      draw(); return api;
    }
  };
  window.BirthCal = BirthCal;

  /* ---------- The Millbridge Pals: your section, followed through the acts ----------
     A FICTIONAL battalion and fictional men, based on the records of real Pals battalions.
     Mates' fates are fixed (five of twelve remain). The visitor's own fate is random,
     weighted towards survival, decided once and remembered in this browser. */
  const MATES = [
    { id: "sam", rank: ["Corporal", "Капрал"], stripes: 2, abbr: ["Cpl", "Капрал"], name: "Sam Entwistle", age: 25, job: ["Bank clerk", "Банковский служащий"], note: ["Commands the section. Quiet, steady, trusted.", "Командует отделением. Спокойный, надёжный, ему доверяют."] },
    { id: "walter", rank: ["Lance-Corporal", "Младший капрал"], stripes: 1, abbr: ["L/Cpl", "Мл. капрал"], name: "Walter Greenhalgh", age: 24, job: ["Coal miner", "Шахтёр"], note: ["Second in command. Strongest man in the section; carries other men\u2019s kit on the march.", "Заместитель командира. Самый сильный в отделении: на марше несёт чужое снаряжение."] },
    { id: "bert", name: "Albert “Bert” Haworth", age: 19, job: ["Weaver, Victoria Mill", "Ткач с фабрики «Виктория»"], note: ["Never without his mouth organ.", "Никогда не расстаётся с губной гармошкой."] },
    { id: "tommy", name: "Tommy Kershaw", age: 21, job: ["Apprentice joiner", "Ученик столяра"], note: ["Writes to his sweetheart Edith every single day.", "Каждый божий день пишет своей девушке Эдит."] },
    { id: "harold", name: "Harold Pilling", age: 18, job: ["Clerk at the Co-op", "Конторщик в кооперативной лавке"], note: ["Best bowler in the works cricket team.", "Лучший подающий в заводской команде по крикету."] },
    { id: "fred", name: "Fred Ashworth", age: 20, job: ["Tram conductor", "Кондуктор трамвая"], note: ["Always joking, even in the rain.", "Шутит всегда, даже под дождём."] },
    { id: "jack", name: "Jack Duckworth", age: 22, job: ["Schoolteacher", "Школьный учитель"], note: ["Writes letters home for the lads who can’t spell.", "Пишет письма домой за тех ребят, которые не в ладах с грамотой."] },
    { id: "arthur", name: "Arthur Holden", age: 26, job: ["Grocer", "Бакалейщик"], note: ["Married, two little girls. Shows everyone the photograph.", "Женат, у него две маленькие дочки. Всем показывает их фотографию."] },
    { id: "billy", name: "Billy Riley", age: 19, job: ["Works football team", "Игрок заводской футбольной команды"], note: ["Fastest runner in Millbridge.", "Самый быстрый бегун в Миллбридже."] },
    { id: "ernest", name: "Ernest Crabtree", age: 23, job: ["Printer’s assistant", "Помощник печатника"], note: ["Draws cartoons of the sergeant in his sketchbook.", "Рисует в альбоме карикатуры на сержанта."] },
    { id: "george", name: "George Whittaker", age: 20, job: ["Your next-door neighbour", "Ваш сосед"], note: ["You have known him since you were five.", "Вы знаете его с пяти лет."] },
    { id: "percy", name: "Percy Lord", age: 18, job: ["Errand boy", "Посыльный"], note: ["The youngest. Everyone looks out for him.", "Самый младший. Все за ним присматривают."] }
  ];
  /* The lads' names in Cyrillic, for the Russian pages (the usual Russian spelling of each English, Scottish, Irish or Welsh name) */
  const CYR = {
    Albert: "Альберт", Alfred: "Альфред", Arthur: "Артур", Bert: "Берт", Charlie: "Чарли", Cyril: "Сирил", Edwin: "Эдвин", Ernest: "Эрнест", Fred: "Фред", Frank: "Фрэнк", George: "Джордж", Harold: "Гарольд", Harry: "Гарри", Herbert: "Герберт", Horace: "Хорас", Jack: "Джек", Joe: "Джо", Leonard: "Леонард", Percy: "Перси", Reg: "Редж", Sam: "Сэм", Sidney: "Сидни", Stanley: "Стэнли", Tom: "Том", Tommy: "Томми", Walter: "Уолтер", Wilfred: "Уилфред", Billy: "Билли", Norman: "Норман",
    Alasdair: "Аласдер", Angus: "Ангус", Archie: "Арчи", Callum: "Каллум", Douglas: "Дуглас", Duncan: "Дункан", Hamish: "Хэмиш", Hector: "Гектор", Iain: "Иэн", Alistair: "Алистер", Jock: "Джок", Lachlan: "Лахлан", Malcolm: "Малкольм", Murdo: "Мердо", Neil: "Нил", Rab: "Рэб", Ross: "Росс", Sandy: "Сэнди", Tam: "Тэм",
    Brendan: "Брендан", Cathal: "Кахал", Christy: "Кристи", Declan: "Деклан", Dermot: "Дермот", Eamon: "Имон", Fergal: "Фергал", Kevin: "Кевин", Liam: "Лиам", Malachy: "Малахи", Michael: "Майкл", Cormac: "Кормак", Paddy: "Пэдди", Patrick: "Патрик", Peadar: "Пэдар", Seamus: "Шеймас", Sean: "Шон", Tadhg: "Тейг",
    Aled: "Алед", Bryn: "Брин", Dai: "Дэй", Dafydd: "Дафидд", Emlyn: "Эмлин", Evan: "Эван", Geraint: "Герайнт", Gwilym: "Гвилим", Huw: "Хью", Idris: "Идрис", Ieuan: "Иеуан", Ivor: "Айвор", Llewellyn: "Ллевелин", Owain: "Оуайн", Rhys: "Рис", Taff: "Тафф", Tudor: "Тюдор", Trefor: "Тревор",
    Ashworth: "Эшворт", Barnes: "Барнс", Birtwistle: "Бертуисл", Clegg: "Клегг", Cooper: "Купер", Crabtree: "Крэбтри", Duckworth: "Дакворт", Entwistle: "Энтуисл", Greenhalgh: "Гринхалш", Haworth: "Хоуорт", Hindle: "Хиндл", Holden: "Холден", Kershaw: "Кершоу", Lord: "Лорд", Marsden: "Марсден", Pilling: "Пиллинг", Riley: "Райли", Shaw: "Шоу", Taylor: "Тейлор", Whittaker: "Уиттакер", Wood: "Вуд", Wright: "Райт", Brierley: "Брайерли", Fletcher: "Флетчер",
    Buchanan: "Бьюкенен", Cameron: "Кэмерон", Campbell: "Кэмпбелл", Ferguson: "Фергюсон", Fraser: "Фрейзер", Gordon: "Гордон", MacDonald: "Макдональд", MacLeod: "Маклауд", McIntyre: "Макинтайр", Munro: "Манро", Murray: "Мюррей", Robertson: "Робертсон", Sinclair: "Синклер", Stewart: "Стюарт",
    Brennan: "Бреннан", Byrne: "Бирн", Callaghan: "Каллахан", Connolly: "Коннолли", Doyle: "Дойл", Duffy: "Даффи", Flanagan: "Фланаган", Gallagher: "Галлахер", Kelly: "Келли", Maguire: "Магуайр", Murphy: "Мерфи", "O'Brien": "О’Брайен", "O'Neill": "О’Нил", Quinn: "Куинн", Sheridan: "Шеридан", Sullivan: "Салливан",
    Bevan: "Беван", Davies: "Дэвис", Evans: "Эванс", Griffiths: "Гриффитс", Hughes: "Хьюз", Jenkins: "Дженкинс", Lewis: "Льюис", Morgan: "Морган", Owen: "Оуэн", Powell: "Пауэлл", Price: "Прайс", Pritchard: "Притчард", Rees: "Рис", Vaughan: "Воан", Williams: "Уильямс"
  };
  const cyr = name => String(name).split(" ").map(w => { const q = w.match(/^“(.+)”$/); return q ? "«" + (CYR[q[1]] || q[1]) + "»" : (CYR[w] || w); }).join(" ");
  const nm = m => LANG() === "ru" ? cyr(m.name) : m.name;      // a mate's name as shown on this page
  const years = n => { const a = n % 10, b = n % 100; return n + " " + (a === 1 && b !== 11 ? "год" : a >= 2 && a <= 4 && (b < 12 || b > 14) ? "года" : "лет"); };
  const LOSSES = { // stage at which each man is lost, and how
    fred: ["may", "killed", ["Killed by a sniper in May 1916. He lifted his head above the parapet for a second.", "Убит снайпером в мае 1916 года. Он на секунду поднял голову над бруствером."]],
    billy: ["july", "killed", ["Killed in no man’s land on 1 July, a few yards past our own wire.", "Убит на ничейной земле 1 июля, в нескольких шагах за нашей собственной проволокой."]],
    arthur: ["july", "killed", ["Killed on 1 July. His wife received the telegram nine days later.", "Убит 1 июля. Его жена получила телеграмму через девять дней."]],
    harold: ["july", "missing", ["Missing on 1 July. Seen going forward; never seen again. His name is on the Thiepval Memorial.", "Пропал без вести 1 июля. Видели, как он шёл вперёд; больше его никто не видел. Его имя высечено на Тьепвальском мемориале."]],
    walter: ["july", "wounded", ["Wounded on 1 July. Crawled back after dark with a bullet in his leg and was sent home to England.", "Ранен 1 июля. Когда стемнело, дополз до своих с пулей в ноге; его отправили домой, в Англию."]],
    ernest: ["autumn", "killed", ["Killed by a shell near Flers in September. His sketchbook was sent home to his mother.", "Убит снарядом под Флером в сентябре. Его альбом с рисунками отправили домой, матери."]],
    percy: ["final", "killed", ["Killed on 13 November 1916 in the last attack near Serre, five days before the battle ended. He was eighteen. The lads had looked out for him for two years.", "Убит 13 ноября 1916 года в последней атаке у Серра, за пять дней до конца битвы. Ему было восемнадцать. Два года ребята присматривали за ним."]]
  };
  /* Every visitor enlists with a different section: first names and surnames are drawn at random from
     English, Scottish, Irish and Welsh names common in 1914, and mixed freely, as they were in the industrial
     towns that raised the Pals. Drawn once per visitor, so the same twelve lads follow them through every act. */
  const FIRST = [
    // English
    "Albert","Alfred","Arthur","Bert","Charlie","Cyril","Edwin","Ernest","Fred","Frank","George","Harold","Harry","Herbert","Horace","Jack","Joe","Leonard","Percy","Reg","Sam","Sidney","Stanley","Tom","Walter","Wilfred","Billy","Norman",
    // Scottish
    "Alasdair","Angus","Archie","Callum","Douglas","Duncan","Hamish","Hector","Iain","Alistair","Jock","Lachlan","Malcolm","Murdo","Neil","Rab","Ross","Sandy","Tam",
    // Irish
    "Brendan","Cathal","Christy","Declan","Dermot","Eamon","Fergal","Kevin","Liam","Malachy","Michael","Cormac","Paddy","Patrick","Peadar","Seamus","Sean","Tadhg",
    // Welsh
    "Aled","Bryn","Dai","Dafydd","Emlyn","Evan","Geraint","Gwilym","Huw","Idris","Ieuan","Ivor","Llewellyn","Owain","Rhys","Taff","Tudor","Trefor"
  ];
  const LAST = [
    // English (many of them Lancashire)
    "Ashworth","Barnes","Birtwistle","Clegg","Cooper","Crabtree","Duckworth","Entwistle","Greenhalgh","Haworth","Hindle","Holden","Kershaw","Lord","Marsden","Pilling","Riley","Shaw","Taylor","Whittaker","Wood","Wright","Brierley","Fletcher",
    // Scottish
    "Buchanan","Cameron","Campbell","Douglas","Ferguson","Fraser","Gordon","MacDonald","MacLeod","McIntyre","Munro","Murray","Robertson","Ross","Sinclair","Stewart",
    // Irish
    "Brennan","Byrne","Callaghan","Connolly","Doyle","Duffy","Flanagan","Gallagher","Kelly","Maguire","Murphy","O'Brien","O'Neill","Quinn","Sheridan","Sullivan",
    // Welsh
    "Bevan","Davies","Evans","Griffiths","Hughes","Jenkins","Lewis","Llewellyn","Morgan","Owen","Powell","Price","Pritchard","Rees","Vaughan","Williams"
  ];
  const draw = (pool, used) => { let n, i = 0; do { n = pool[Math.floor(Math.random() * pool.length)]; } while (used.has(n) && ++i < 200); used.add(n); return n; };
  /* Jobs held by men of the Pals battalions in 1914. "young" jobs go only to lads of 18 or 19. */
  const JOBS = [
    ["Bank clerk", "Банковский служащий"], ["Coal miner", "Шахтёр"], ["Weaver at the cotton mill", "Ткач на хлопкопрядильной фабрике"],
    ["Apprentice joiner", "Ученик столяра"], ["Clerk at the Co-op", "Конторщик в кооперативной лавке"], ["Tram conductor", "Кондуктор трамвая"],
    ["Schoolteacher", "Школьный учитель"], ["Grocer", "Бакалейщик"], ["Printer\u2019s assistant", "Помощник печатника"],
    ["Railway porter", "Носильщик на железной дороге"], ["Blacksmith\u2019s striker", "Молотобоец в кузнице"], ["Baker", "Пекарь"],
    ["Plumber\u2019s mate", "Подручный водопроводчика"], ["Draper\u2019s shop assistant", "Приказчик в мануфактурной лавке"], ["Insurance clerk", "Страховой агент"],
    ["Brewery drayman", "Возчик на пивоварне"], ["Engine fitter", "Слесарь-механик"], ["Cotton spinner", "Прядильщик"], ["Bricklayer", "Каменщик"],
    ["Postman", "Почтальон"], ["Butcher\u2019s assistant", "Помощник мясника"], ["Gardener at the park", "Садовник в городском парке"],
    ["Footballer for the works team", "Футболист заводской команды"], ["Shipping clerk", "Конторщик в транспортной конторе"]
  ];
  const YOUNG_JOBS = [["Errand boy", "Посыльный"], ["Telegraph boy", "Разносчик телеграмм"], ["Mill half-timer", "Подросток-рабочий на фабрике"]];
  // ages each man can be drawn at: NCOs older, Arthur old enough to be married with two daughters, Percy the youngest at 18 (his fate says so)
  const AGE_RANGE = { sam: [24, 30], walter: [22, 28], arthur: [26, 33], percy: [18, 18] };
  const randInt = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  function newProfiles() { // a fresh age and job for every man; no two share a job
    const used = new Set(), out = {};
    MATES.forEach(m => {
      const [lo, hi] = AGE_RANGE[m.id] || [19, 26], age = randInt(lo, hi);
      const pool = age <= 19 ? JOBS.concat(YOUNG_JOBS) : JOBS;
      let j; do { j = pool[Math.floor(Math.random() * pool.length)]; } while (used.has(j[0]) && used.size < pool.length);
      used.add(j[0]); out[m.id] = { age, job: j };
    });
    return out;
  }
  function newRoster() { const f = new Set(), l = new Set(), r = {}; MATES.forEach(m => { r[m.id] = draw(FIRST, f) + " " + draw(LAST, l); }); r.profiles = newProfiles(); return r; }
  function myRoster() {
    let r = null; try { r = JSON.parse(store.get("somme-pals-roster")); } catch (e) {}
    if (!r || typeof r !== "object" || MATES.some(m => !r[m.id])) { r = (Progress.get().roster) || newRoster(); }
    if (!r.profiles) r.profiles = newProfiles(); // sections raised before ages and jobs were drawn too
    store.set("somme-pals-roster", JSON.stringify(r));
    return r;
  }
  /* The site's author always gets the original Millbridge lads; every other visitor gets a random section. */
  const ORIGINAL = Object.fromEntries(MATES.map(m => [m.id, m.name]));
  ORIGINAL.profiles = Object.fromEntries(MATES.map(m => [m.id, { age: m.age, job: m.job }]));
  const applyRoster = r => MATES.forEach(m => { m.name = r[m.id]; const pr = r.profiles && r.profiles[m.id]; if (pr) { m.age = pr.age; m.job = pr.job; } });
  const isAuthor = () => store.get("somme-author") === "1";
  applyRoster(isAuthor() ? ORIGINAL : myRoster());
  // ask the page host whether the author is viewing; if that changes the answer, swap the names already on the page
  (async () => {
    try {
      const u = window.claude && claude.use ? await claude.use("user") : null; if (!u || !u.isOwner) return;
      const owner = !!(await u.isOwner()); if (owner === isAuthor()) return;
      store.set("somme-author", owner ? "1" : "");
      const before = MATES.map(nm), jackWas = firstOf("jack"); applyRoster(owner ? ORIGINAL : myRoster());
      document.querySelectorAll(".roll b").forEach(b => { before.forEach((n, i) => { if (b.firstChild && b.firstChild.nodeType === 3 && b.firstChild.textContent.includes(n)) b.firstChild.textContent = b.firstChild.textContent.replace(n, nm(MATES[i])); }); });
      document.querySelectorAll(".roll .reroll").forEach(r => { r.hidden = owner; });
      document.querySelectorAll(".roll .fate[data-jack]").forEach(f => { f.textContent = f.textContent.replace(jackWas, firstOf("jack")); });
    } catch (e) {}
  })();
  const firstOf = id => nm(MATES.find(m => m.id === id) || { name: "" }).split(" ")[0];
  const ORDER = ["intro", "may", "july", "autumn", "final"];
  const lostBy = (id, stage) => LOSSES[id] && ORDER.indexOf(LOSSES[id][0]) <= ORDER.indexOf(stage);
  function myFate() {
    let f = store.get("somme-pals-fate");
    if (!["unhurt", "wounded", "killed"].includes(f)) {
      const r = Math.random();
      f = r < .6 ? "unhurt" : r < .85 ? "wounded" : "killed";
      store.set("somme-pals-fate", f);
    }
    return f;
  }
  // the visitor's own fate at each roll call: [status, English, Russian]; "jack" is replaced with that mate's first name
  const YOU = {
    july: { unhurt: ["present", "You answer: “Here, Sergeant.” You don’t know how you are still alive.", "Вы отвечаете: «Здесь, сержант!» Вы сами не понимаете, как остались живы."],
            wounded: ["wounded", "You are not at the roll call. You are on a stretcher, then a hospital train, then a ship home, with a bullet wound in your shoulder.", "На перекличке вас нет. С пулевым ранением в плечо вы лежите на носилках, потом в санитарном поезде, потом на корабле, который идёт домой."],
            killed: ["missing", "Nobody answers for you. You fell in no man’s land, and your body was never identified.", "За вас никто не отвечает. Вы пали на ничейной земле, и ваше тело так и не опознали."] },
    autumn: { unhurt: ["present", "You are still here. Fewer faces answer every time.", "Вы всё ещё здесь. С каждым разом откликается всё меньше голосов."],
              wounded: ["wounded", "You hear the news in a letter from jack, in a hospital bed in England.", "Вы лежите в госпитале в Англии. Обо всём вам пишет в письме jack."],
              killed: ["missing", "The section goes on without you.", "Отделение идёт дальше без вас."] },
    final: { unhurt: ["present", "You came through the Somme. You will carry their names for the rest of your life.", "Вы прошли через Сомму. Их имена вы пронесёте через всю свою жизнь."],
             wounded: ["wounded", "You survived, with a wound that aches every winter. You never went back to the Somme, but you never really left it either.", "Вы выжили, но рана ноет каждую зиму. Вы больше никогда не возвращались на Сомму, но и по-настоящему покинуть её так и не смогли."],
             killed: ["missing", "Your name is carved on the Thiepval Memorial, among more than 72,000 men with no known grave. Years later, your mates travel to France to find it.", "Ваше имя высечено на Тьепвальском мемориале, среди имён более чем 72 000 человек, чьи могилы неизвестны. Много лет спустя ваши товарищи приезжают во Францию, чтобы отыскать там ваше имя."] }
  };
  const STAGE = {
    may: [["Roll call", "Перекличка"], ["May 1916 · the trenches opposite Serre", "Май 1916 · окопы напротив Серра"]],
    july: [["Roll call", "Перекличка"], ["Evening, 1 July 1916", "Вечер 1 июля 1916 года"]],
    autumn: [["Roll call", "Перекличка"], ["Late September 1916 · after Flers", "Конец сентября 1916 · после Флера"]],
    final: [["The Millbridge Pals", "Миллбриджские приятели"], ["November 1916 · the battle ends", "Ноябрь 1916 · битва окончена"]]
  };
  // the word shown in the status column of a roll call
  const STATUS = { present: ["Present", "Здесь"], killed: ["killed", "убит"], wounded: ["wounded", "ранен"], missing: ["missing", "пропал без вести"] };
  const YOU_STATUS = { present: ["Present", "Здесь"], wounded: ["wounded", "ранены"], missing: ["missing", "пропали без вести"] };
  const esc = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const rn = m => esc((m.abbr ? L(m.abbr) + " " : "") + nm(m));
  // rank chevrons, point down, as worn on the upper sleeve
  const chev = n => !n ? "" : `<svg class="chev" viewBox="0 0 24 ${4 + n * 7}" width="24" height="${4 + n * 7}" role="img" aria-label="${T(n + " " + (n > 1 ? "stripes" : "stripe"), n === 1 ? "1 нашивка" : n + " нашивки")}">${Array.from({ length: n }, (_, i) => `<polyline points="3,${3 + i * 7} 12,${8 + i * 7} 21,${3 + i * 7}"/>`).join("")}</svg>`;
  /* ---------- Everything that belongs to one page. Runs on first load and after every in-site page change. ---------- */
  function initPage() {
    document.querySelectorAll("[data-act-link]").forEach(a => { if (a.dataset.actLink === curAct()) a.setAttribute("aria-current", "true"); else a.removeAttribute("aria-current"); });
    Progress.visit(baseName(location.pathname));
    Account.changed();
    // the language switch points at this same page in the other language
    store.set("somme-lang", LANG());
    document.querySelectorAll("[data-lang-link]").forEach(a => {
      const other = LANG() === "ru" ? "en" : "ru";
      a.href = inLang(baseName(location.pathname) + location.hash, other);
      a.onclick = () => store.set("somme-lang", other);
    });
  /* ---------- Next-page pull ---------- */
    const nx = body.dataset.next;
    if (nx) {
      const [href, title, kicker] = nx.split("|");
      const sec = document.createElement("nav");
      sec.className = "next wrap"; sec.setAttribute("aria-label", T("Next page", "Следующая страница"));
      sec.innerHTML = `<p class="eyebrow">${kicker || T("Keep going", "Дальше")}</p><a class="go" href="${href}">${title} <span>${T("Next", "Дальше")} &rarr;</span></a>`;
      const main = document.querySelector("main");
      (main || body).append(sec);
    }
  
  
  document.querySelectorAll(".roll[data-stage]").forEach(el => {
      const stage = el.dataset.stage, fate = myFate();
      const fictional = `<p class="roll-note">${T("The Millbridge Pals and these men are fictional, based on the records of real Pals battalions.", "«Миллбриджские приятели» и все эти люди вымышлены; они созданы по документам настоящих батальонов приятелей.")}</p>`;
      if (stage === "intro") {
        el.innerHTML = `<div class="roll-head"><span class="eyebrow">${T("September 1914 · the Drill Hall, Market Street", "Сентябрь 1914 · строевой зал на Маркет-стрит")}</span><h2>${T("Your section", "Ваше отделение")}</h2>
          <p>${T("You enlist with twelve lads you have known half your life. The recruiting sergeant writes your names in the ledger one after another: No. 3 Section, the Millbridge Pals. Wherever you go now, you go together.", "Вы записываетесь добровольцем вместе с двенадцатью парнями, которых знаете полжизни. Сержант-вербовщик заносит ваши имена в книгу одно за другим: 3-е отделение, «Миллбриджские приятели». Куда бы вас теперь ни отправили, вы отправитесь вместе.")}</p></div>
          <ul class="mates">${MATES.map(m => `<li${m.rank ? ' class="nco"' : ""}>${chev(m.stripes)}<b>${esc(nm(m))}</b><span class="meta">${m.rank ? L(m.rank) : T("Private", "Рядовой")} · ${T(m.age, years(m.age))} · ${esc(L(m.job))}</span><span>${esc(L(m.note))}</span></li>`).join("")}
          <li class="you"><b>${T("You", "Вы")}</b><span class="meta">${T("Private · 19 · Millbridge", "Рядовой · 19 лет · Миллбридж")}</span><span>${T("Whatever happens next, you will see it with them.", "Что бы ни случилось дальше, вы увидите это вместе с ними.")}</span></li></ul>
          <p class="reroll"${isAuthor() ? " hidden" : ""}><button class="btn" type="button" data-reroll>${T("Raise a different section", "Собрать другое отделение")}</button> <span>${T("New names, ages and jobs, drawn from English, Scottish, Irish and Welsh families.", "Новые имена, возраст и профессии; имена из английских, шотландских, ирландских и валлийских семей.")}</span></p>${fictional}`;
        el.querySelector("[data-reroll]").addEventListener("click", () => {
          const r = newRoster(); store.set("somme-pals-roster", JSON.stringify(r)); applyRoster(r);
          const p = Progress.get(); p.roster = r; Progress.save(p);
          el.querySelectorAll(".mates li:not(.you)").forEach((li, i) => {
            const m = MATES[i]; li.querySelector("b").textContent = nm(m);
            li.querySelector(".meta").textContent = (m.rank ? L(m.rank) : T("Private", "Рядовой")) + " · " + T(m.age, years(m.age)) + " · " + L(m.job);
          });
          el.classList.remove("rerolled"); void el.offsetWidth; el.classList.add("rerolled");
        });
        return;
      }
      const lostNow = MATES.filter(m => LOSSES[m.id] && LOSSES[m.id][0] === stage);
      const present = MATES.filter(m => !lostBy(m.id, stage));
      const rows = MATES.map(m => {
        const gone = lostBy(m.id, stage), now = LOSSES[m.id] && LOSSES[m.id][0] === stage;
        if (!gone) return `<li class="present"><b>${rn(m)}${chev(m.stripes)}</b><span class="st">${L(STATUS.present)}</span></li>`;
        const [, kind, text] = LOSSES[m.id];
        if (stage !== "final" && !now) return `<li class="gone faded ${kind}"><b>${rn(m)}${chev(m.stripes)}</b><span class="st">${L(STATUS[kind])}</span></li>`;
        return `<li class="gone ${kind}${now ? " now" : ""}"><b>${rn(m)}${chev(m.stripes)}</b><span class="st">${L(STATUS[kind])}</span><span class="fate">${esc(L(text))}</span></li>`;
      }).join("");
      let youRow = "";
      if (stage === "may") youRow = `<li class="present you"><b>${T("You", "Вы")}</b><span class="st">${L(YOU_STATUS.present)}</span></li>`;
      else { const [st, en, ru] = YOU[stage][fate], txt = T(en, ru), j = txt.includes("jack"); youRow = `<li class="${st === "present" ? "present" : "gone now " + st} you"><b>${T("You", "Вы")}</b><span class="st">${L(YOU_STATUS[st])}</span><span class="fate"${j ? " data-jack" : ""}>${esc(txt.replace("jack", firstOf("jack")))}</span></li>`; }
      const title = L(STAGE[stage][0]), when = L(STAGE[stage][1]);
      const count = stage === "final"
        ? T("Five of your twelve mates are still standing when the battle ends.", "Из двенадцати ваших товарищей к концу битвы в строю остаются пятеро.")
        : T(`${present.length} of 12 answer their names.`, `${present.length} из 12 откликаются на свои имена.`);
      el.innerHTML = `<div class="roll-head"><span class="eyebrow">${when}</span><h2>${title}</h2><p class="count">${count}</p></div><ol class="names-roll">${rows}${youRow}</ol>${fictional}`;
    });
    // An enlisted visitor answers the roll call under their own name
    if (document.querySelector(".roll .you")) Account.load().then(rec => {
      if (!rec) return;
      document.querySelectorAll(".roll .you > b").forEach(b => {
        b.textContent = (b.closest(".mates") ? (rankOf(rec).key === "pte" ? "" : rankOf(rec).short + " ") : rankOf(rec).short + " ") + rec.name + " "; // the opening list already says "Private"
        const meta = b.parentElement.querySelector(".meta");
        if (meta && b.closest(".mates")) { // rank, real age and home town; a recruit under 18 does what many boys did, and claims to be 18
          const n = ageOf(rec.born), age = n == null ? T("19", "19 лет") : n < 18 ? T(n + ", but tells the sergeant 18", years(n) + ", но сержанту называет 18") : T(String(n), years(n));
          meta.textContent = rankOf(rec).long + " · " + age + " · " + (rec.hometown || T("Millbridge", "Миллбридж"));
        }
        const tag = document.createElement("small"); tag.className = "you-tag"; tag.textContent = T("(you)", "(вы)"); b.append(tag);
        if (pipFor(rec)) b.insertAdjacentHTML("beforeend", pipFor(rec));
      });
    });
  
    /* ---------- Film clips: pause button, and start paused for reduced motion ---------- */
    document.querySelectorAll(".film").forEach(fig => {
      const v = fig.querySelector("video"), btn = fig.querySelector(".film-toggle");
      if (!v || !btn || btn.dataset.wired || btn.id === "crowds-toggle") return; // The Call wires its own
      btn.dataset.wired = "1";
      const set = play => { if (play) v.play().catch(() => {}); else v.pause(); btn.textContent = play ? T("Pause film", "Пауза") : T("Play film", "Смотреть"); btn.setAttribute("aria-pressed", String(!play)); };
      btn.addEventListener("click", () => set(v.paused));
      if (matchMedia("(prefers-reduced-motion: reduce)").matches) set(false);
    });
  
    /* ---------- Full-bleed background films: silent, slowed, only while on screen.
       Phones, data saver and reduced motion get the still poster instead. ---------- */
    const stillOnly = matchMedia("(prefers-reduced-motion: reduce)").matches || matchMedia("(max-width: 700px)").matches || (navigator.connection && navigator.connection.saveData);
    document.querySelectorAll(".bleed video[data-srcs]").forEach(v => {
      if (stillOnly) return;
      v.dataset.srcs.split("|").forEach(src => { const s = document.createElement("source"); s.src = src; s.type = src.endsWith(".webm") ? "video/webm" : "video/mp4"; v.appendChild(s); });
      v.muted = true; v.loop = true; v.playsInline = true; v.load();
      const rate = +v.dataset.rate || 1; v.addEventListener("loadedmetadata", () => { v.playbackRate = rate; });
      new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) v.play().catch(() => {}); else v.pause(); })).observe(v);
    });
  
    /* ---------- Hard-cut slideshows: instant swaps, no fades. Reduced motion keeps the first photo. ---------- */
    document.querySelectorAll(".bleed[data-cuts]").forEach(sec => {
      const imgs = [...sec.querySelectorAll(".bg > img")]; if (!imgs.length) return;
      let k = 0, timer = null; imgs[0].classList.add("on");
      if (imgs.length < 2 || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      const every = +sec.dataset.cuts || 2600;
      const tick = () => { imgs[k].classList.remove("on"); k = (k + 1) % imgs.length; imgs[k].classList.add("on"); };
      new IntersectionObserver(es => es.forEach(e => { clearInterval(timer); if (e.isIntersecting) timer = setInterval(tick, every); })).observe(sec);
      pageCtl.signal.addEventListener("abort", () => clearInterval(timer));
    });
  
    /* ---------- Tables become stacked cards on phones: label each cell with its column heading ---------- */
    document.querySelectorAll(".tablewrap table").forEach(t => {
      const heads = [...t.querySelectorAll("thead th")].map(th => th.textContent.trim());
      t.querySelectorAll("tbody tr").forEach(tr => [...tr.children].forEach((td, i) => { if (heads[i]) td.setAttribute("data-label", heads[i]); }));
    });

    /* ---------- Labelled plates: pins and key light each other up ---------- */
    document.querySelectorAll(".plate-dia").forEach(fig => {
      const pins = [...fig.querySelectorAll(".pin")], items = [...fig.querySelectorAll(".pd-key li")];
      const set = n => { pins.forEach(p => p.classList.toggle("on", p.dataset.n === n)); items.forEach(i => i.classList.toggle("on", i.dataset.n === n)); };
      pins.forEach(p => {
        p.addEventListener("mouseenter", () => set(p.dataset.n)); p.addEventListener("focus", () => set(p.dataset.n));
        p.addEventListener("click", () => { set(p.dataset.n); const li = items.find(i => i.dataset.n === p.dataset.n); if (li && matchMedia("(max-width: 700px)").matches) li.scrollIntoView({ block: "nearest", behavior: "smooth" }); });
      });
      items.forEach(i => { i.addEventListener("mouseenter", () => set(i.dataset.n)); });
      fig.addEventListener("mouseleave", () => set(null));
    });

    /* ---------- Pin labels near the edge of a picture open inwards, so they never run off the screen ---------- */
    document.querySelectorAll(".pin").forEach(p => { const x = parseFloat(p.style.getPropertyValue("--x")); p.classList.toggle("tip-l", x > 72); p.classList.toggle("tip-r", x < 28); });

    /* ---------- Before/after sliders ---------- */
    document.querySelectorAll(".compare").forEach(c => {
      const stage = c.querySelector(".stage"), r = c.querySelector("input[type=range]");
      const upd = () => stage.style.setProperty("--pos", r.value + "%");
      r.addEventListener("input", upd); upd();
    });
  
  }
  initPage();

  /* ---------- Moving between pages without reloading, so the sound never has to stop ----------
     Browsers silence a freshly loaded page until the visitor clicks something. Instead of loading
     a new document, we fetch the next page, swap its content into this one and keep the same
     sound engine running. If anything goes wrong we simply fall back to an ordinary page load. */
  const withPageScope = fn => {
    const si = window.setInterval;
    window.setInterval = (...a) => { const id = si(...a); pageTimers.push(id); return id; };
    try { fn(); } finally { window.setInterval = si; }
  };
  const isPage = a => {
    if (!a || a.target && a.target !== "_self" || a.hasAttribute("download")) return false;
    const u = new URL(a.href, location.href);
    if (u.origin !== location.origin || !/\.html$/.test(u.pathname)) return false;
    const same = x => x.replace(/\.html$/, "").replace(/\/index$/, "/");
    if (same(u.pathname) === same(location.pathname) && u.hash) return false; // a jump within this page
    return u;
  };
  // ---- loading ahead: pages and their pictures are fetched before they are needed ----
  const pageCache = new Map(), imgCache = new Set();
  const fetchPage = url => {
    const key = url.href.split("#")[0];
    if (!pageCache.has(key)) pageCache.set(key, fetch(key).then(r => { if (!r.ok) throw 0; return r.text(); }).catch(e => { pageCache.delete(key); throw e; }));
    return pageCache.get(key);
  };
  const pictureUrls = (doc, base) => {
    const out = [];
    doc.querySelectorAll("img[src], video[poster]").forEach(n => out.push(new URL(n.getAttribute(n.tagName === "IMG" ? "src" : "poster"), base).href));
    return [...new Set(out)];
  };
  const warmImages = (doc, base, maxWait) => {
    const jobs = pictureUrls(doc, base).map(src => new Promise(res => {
      if (imgCache.has(src)) return res();
      const im = new Image(); im.onload = im.onerror = () => { imgCache.add(src); res(); }; im.src = src;
    }));
    return Promise.race([Promise.all(jobs), new Promise(r => setTimeout(r, maxWait))]);
  };
  // while the visitor reads, quietly fetch the next page and its pictures
  const prefetchNext = () => {
    const nx = body.dataset.next; if (!nx) return;
    const url = new URL(nx.split("|")[0], location.href);
    const idle = window.requestIdleCallback || (f => setTimeout(f, 1200));
    idle(() => fetchPage(url).then(html => warmImages(new DOMParser().parseFromString(html, "text/html"), url, 60000)).catch(() => {}));
  };
  if (document.readyState === "complete") prefetchNext(); else window.addEventListener("load", prefetchNext, { once: true });

  async function go(url, push) {
    let html;
    try { html = await fetchPage(url); }
    catch (e) { location.href = url.href; return; }
    const doc = new DOMParser().parseFromString(html, "text/html");
    // switching language: load the page afresh, so every font, label and menu is in the new language
    if ((doc.body && doc.body.dataset.lang === "ru" ? "ru" : "en") !== LANG()) { location.href = url.href; return; }
    await warmImages(doc, url, 2500); // show the page with its pictures already there (but never wait more than 2.5 s)
    // leave the old page: close the Archive menu, stop its timers, listeners, films and any gunfire
    { const al = document.getElementById("archive-list"), ab = document.getElementById("archive-btn"); if (al) al.hidden = true; if (ab) ab.setAttribute("aria-expanded", "false"); }
    pageCtl.abort(); pageCtl = new AbortController(); pageTimers.forEach(clearInterval); pageTimers = [];
    document.querySelectorAll("video, audio").forEach(m => { try { m.pause(); } catch (e) {} });
    if (window.Sound) { try { Sound.stopMG && Sound.stopMG(.2); } catch (e) {} }
    // swap the page's own styles
    document.querySelectorAll("style[data-page]").forEach(n => n.remove());
    // keep each style's place relative to the shared stylesheet: the host's own defaults come before it, the page's styles after it
    const sheetIn = d => d.querySelector('link[rel~=stylesheet][href$="site.css"]');
    const docSheet = sheetIn(doc), newStyles = [], baseStyles = [];
    doc.querySelectorAll("style").forEach(st => {
      const n = document.createElement("style"); n.dataset.page = ""; n.textContent = st.textContent;
      const before = docSheet && (st.compareDocumentPosition(docSheet) & Node.DOCUMENT_POSITION_FOLLOWING);
      (before ? baseStyles : newStyles).push(n);
    });
    // swap the body: keep the header, footer, grain and fog; replace the rest
    [...body.attributes].forEach(at => { if (at.name === "class" || at.name.startsWith("data-")) body.removeAttribute(at.name); });
    [...doc.body.attributes].forEach(at => body.setAttribute(at.name, at.value));
    [...body.children].forEach(n => { if (!("keep" in n.dataset) && n.tagName !== "SCRIPT" && n.tagName !== "LINK" && !n.tagName.includes("-")) n.remove(); });
    if (!document.querySelector('link[rel~=stylesheet][href$="site.css"]')) { const l = document.createElement("link"); l.rel = "stylesheet"; l.href = "site.css"; document.head.append(l); }
    const anchor = body.querySelector(":scope > .grain") || body.querySelector(":scope > .site-foot") || null;
    { const live = sheetIn(document); baseStyles.forEach(n => live ? live.parentNode.insertBefore(n, live) : document.head.prepend(n)); }
    newStyles.forEach(n => body.insertBefore(n, anchor)); // after the shared stylesheet, so page rules win as they did before
    const scripts = [...doc.querySelectorAll("script")].filter(n => !n.src && !/site\.js$/.test(n.getAttribute("src") || ""));
    [...doc.body.children].forEach(n => {
      if (n.tagName === "SCRIPT" || n.tagName === "STYLE" || n.tagName === "LINK" || n.tagName === "TITLE") return;
      body.insertBefore(document.importNode(n, true), anchor);
    });
    document.title = (doc.querySelector("title") || {}).textContent || document.title;
    if (push) history.pushState({ soft: 1 }, "", url.href);
    // run the new page's own scripts, then the shared per-page setup
    withPageScope(() => {
      scripts.forEach(old => { const n = document.createElement("script"); n.textContent = old.textContent; n.dataset.page = ""; body.insertBefore(n, anchor); });
      initPage();
    });
    const r = document.documentElement, prev = r.style.scrollBehavior; r.style.scrollBehavior = "auto";
    const target = url.hash && document.getElementById(decodeURIComponent(url.hash.slice(1)));
    if (target) target.scrollIntoView(); else window.scrollTo(0, 0);
    r.style.scrollBehavior = prev;
    const h1 = document.querySelector("main h1"); if (h1) { h1.tabIndex = -1; h1.focus({ preventScroll: true }); }
    if (window.Sound && Sound.enabled) Sound.pageAmbient();
    prefetchNext();
  }
  // mark the first page's own styles so they can be swapped out later
  document.querySelectorAll("style").forEach(st => { st.dataset.page = ""; });
  document.addEventListener("click", e => {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target.closest("a[href]"), u = isPage(a); if (!u) return;
    e.preventDefault(); go(u, true);
  });
  window.addEventListener("popstate", () => go(new URL(location.href), false));
  const early = e => { const u = isPage(e.target.closest && e.target.closest("a[href]")); if (u) fetchPage(u).catch(() => {}); };
  document.addEventListener("pointerover", early, { passive: true }); document.addEventListener("touchstart", early, { passive: true });
  for (const target of [document, window]) {
    const add = target.addEventListener;
    target.addEventListener = function (type, fn, opts) {
      const o = typeof opts === "object" && opts ? { ...opts } : { capture: !!opts };
      if (!o.signal) o.signal = pageCtl.signal;
      return add.call(this, type, fn, o);
    };
  }
})();
